import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, real, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users/Athletes table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  sport: text("sport").notNull(),
  skillLevel: text("skill_level").notNull(), // Amateur, Pro, Elite
  age: integer("age").notNull(),
  location: text("location").notNull(),
  bio: text("bio"),
  avatar: text("avatar"),
  talentScore: integer("talent_score").default(0),
  isActive: boolean("is_active").default(true),
});

// Video analyses table
export const videoAnalyses = pgTable("video_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  videoUrl: text("video_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  title: text("title").notNull(),
  description: text("description"),
  technique: integer("technique").notNull(),
  power: integer("power").notNull(),
  balance: integer("balance").notNull(),
  overallScore: integer("overall_score").notNull(),
  aiFeedback: text("ai_feedback").notNull(),
  keyArea: text("key_area"),
  priority: text("priority"), // Low, Medium, High
  confidence: integer("confidence").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Performance metrics table
export const performanceMetrics = pgTable("performance_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  speed: integer("speed").default(0),
  technique: integer("technique").default(0),
  endurance: integer("endurance").default(0),
  power: integer("power").default(0),
  balance: integer("balance").default(0),
  agility: integer("agility").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Coaches table
export const coaches = pgTable("coaches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  specialization: text("specialization").notNull(),
  experience: integer("experience").notNull(),
  rating: real("rating").default(0),
  ratePerHour: integer("rate_per_hour").notNull(),
  athletesCoached: integer("athletes_coached").default(0),
  avatar: text("avatar"),
  bio: text("bio"),
  isAvailable: boolean("is_available").default(true),
});

// Coaching sessions table
export const coachingSessions = pgTable("coaching_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  coachId: varchar("coach_id").notNull(),
  sessionType: text("session_type").notNull(),
  scheduledAt: timestamp("scheduled_at").notNull(),
  duration: integer("duration").notNull(), // in minutes
  status: text("status").notNull(), // scheduled, completed, cancelled
  notes: text("notes"),
  rating: integer("rating"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Challenges table
export const challenges = pgTable("challenges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // weekly, monthly, special
  requirements: json("requirements").notNull(), // Array of requirements
  badge: text("badge"),
  prizePool: integer("prize_pool"),
  participants: integer("participants").default(0),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
});

// Challenge progress table
export const challengeProgress = pgTable("challenge_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  challengeId: varchar("challenge_id").notNull(),
  progress: integer("progress").default(0), // percentage
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Sponsorship profiles table
export const sponsorshipProfiles = pgTable("sponsorship_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  fundingGoal: integer("funding_goal").notNull(),
  currentFunding: integer("current_funding").default(0),
  sponsorCount: integer("sponsor_count").default(0),
  achievements: json("achievements"), // Array of achievements
  trainingHours: integer("training_hours").default(0),
  recentAchievement: text("recent_achievement"),
  isActive: boolean("is_active").default(true),
});

// Badges/Achievements table
export const badges = pgTable("badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  badgeType: text("badge_type").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  icon: text("icon"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  talentScore: true,
  isActive: true,
});

export const insertVideoAnalysisSchema = createInsertSchema(videoAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertPerformanceMetricsSchema = createInsertSchema(performanceMetrics).omit({
  id: true,
  updatedAt: true,
});

export const insertCoachSchema = createInsertSchema(coaches).omit({
  id: true,
  rating: true,
  athletesCoached: true,
  isAvailable: true,
});

export const insertCoachingSessionSchema = createInsertSchema(coachingSessions).omit({
  id: true,
  createdAt: true,
});

export const insertChallengeSchema = createInsertSchema(challenges).omit({
  id: true,
  participants: true,
  isActive: true,
});

export const insertChallengeProgressSchema = createInsertSchema(challengeProgress).omit({
  id: true,
  completedAt: true,
  updatedAt: true,
});

export const insertSponsorshipProfileSchema = createInsertSchema(sponsorshipProfiles).omit({
  id: true,
  currentFunding: true,
  sponsorCount: true,
  isActive: true,
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
  earnedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type VideoAnalysis = typeof videoAnalyses.$inferSelect;
export type InsertVideoAnalysis = z.infer<typeof insertVideoAnalysisSchema>;

export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = z.infer<typeof insertPerformanceMetricsSchema>;

export type Coach = typeof coaches.$inferSelect;
export type InsertCoach = z.infer<typeof insertCoachSchema>;

export type CoachingSession = typeof coachingSessions.$inferSelect;
export type InsertCoachingSession = z.infer<typeof insertCoachingSessionSchema>;

export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;

export type ChallengeProgress = typeof challengeProgress.$inferSelect;
export type InsertChallengeProgress = z.infer<typeof insertChallengeProgressSchema>;

export type SponsorshipProfile = typeof sponsorshipProfiles.$inferSelect;
export type InsertSponsorshipProfile = z.infer<typeof insertSponsorshipProfileSchema>;

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
