import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import AthleteProfile from "@/pages/athlete-profile";
import VideoAnalysis from "@/pages/video-analysis";
import Leaderboard from "@/pages/leaderboard";
import CoachingHub from "@/pages/coaching-hub";
import SponsorshipMarketplace from "@/pages/sponsorship-marketplace";
import Navigation from "@/components/ui/navigation";

function Router() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/profile" component={AthleteProfile} />
        <Route path="/video-analysis" component={VideoAnalysis} />
        <Route path="/leaderboard" component={Leaderboard} />
        <Route path="/coaching" component={CoachingHub} />
        <Route path="/sponsorship" component={SponsorshipMarketplace} />
        <Route component={NotFound} />
      </Switch>
      <Navigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
