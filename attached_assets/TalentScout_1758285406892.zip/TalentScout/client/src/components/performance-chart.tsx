import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

interface PerformanceMetrics {
  speed: number;
  technique: number;
  endurance: number;
  power: number;
  balance: number;
  agility: number;
}

interface PerformanceChartProps {
  metrics: PerformanceMetrics;
  title?: string;
}

export default function PerformanceChart({ metrics, title = "Performance Radar" }: PerformanceChartProps) {
  // Create a simple radar chart representation
  const categories = [
    { key: 'speed', label: 'Speed', value: metrics.speed },
    { key: 'technique', label: 'Technique', value: metrics.technique },
    { key: 'endurance', label: 'Endurance', value: metrics.endurance },
    { key: 'power', label: 'Power', value: metrics.power },
    { key: 'balance', label: 'Balance', value: metrics.balance },
    { key: 'agility', label: 'Agility', value: metrics.agility },
  ];

  // Calculate points for a hexagon (6 sides)
  const centerX = 120;
  const centerY = 120;
  const radius = 80;
  const maxRadius = 100;

  const getPointCoordinates = (index: number, value: number) => {
    const angle = (index * 60 - 90) * (Math.PI / 180); // Start from top, 60 degrees apart
    const distance = (value / 100) * radius;
    return {
      x: centerX + Math.cos(angle) * distance,
      y: centerY + Math.sin(angle) * distance,
    };
  };

  const getGridCoordinates = (index: number, radiusPercent: number) => {
    const angle = (index * 60 - 90) * (Math.PI / 180);
    const distance = (radiusPercent / 100) * maxRadius;
    return {
      x: centerX + Math.cos(angle) * distance,
      y: centerY + Math.sin(angle) * distance,
    };
  };

  // Generate radar chart data points
  const dataPoints = categories.map((category, index) => 
    getPointCoordinates(index, category.value)
  );

  // Create path string for the radar chart
  const pathData = dataPoints.map((point, index) => 
    `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`
  ).join(' ') + ' Z';

  // Grid lines (3 concentric hexagons)
  const gridLevels = [33, 66, 100];
  const gridPaths = gridLevels.map(level => {
    const gridPoints = Array.from({ length: 6 }, (_, index) => 
      getGridCoordinates(index, level)
    );
    return gridPoints.map((point, index) => 
      `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`
    ).join(' ') + ' Z';
  });

  // Axis lines
  const axisLines = Array.from({ length: 6 }, (_, index) => {
    const endPoint = getGridCoordinates(index, 100);
    return `M ${centerX} ${centerY} L ${endPoint.x} ${endPoint.y}`;
  });

  return (
    <Card data-testid="performance-chart">
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="w-5 h-5 mr-2" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <svg 
            width="240" 
            height="240" 
            className="mx-auto" 
            viewBox="0 0 240 240"
            data-testid="radar-chart-svg"
          >
            {/* Grid */}
            {gridPaths.map((path, index) => (
              <path
                key={`grid-${index}`}
                d={path}
                fill="none"
                stroke="hsl(var(--border))"
                strokeWidth="1"
                opacity={0.3}
              />
            ))}
            
            {/* Axis lines */}
            {axisLines.map((line, index) => (
              <path
                key={`axis-${index}`}
                d={line}
                stroke="hsl(var(--border))"
                strokeWidth="1"
                opacity={0.2}
              />
            ))}

            {/* Data area */}
            <path
              d={pathData}
              fill="hsl(var(--primary))"
              fillOpacity="0.1"
              stroke="hsl(var(--primary))"
              strokeWidth="2"
            />

            {/* Data points */}
            {dataPoints.map((point, index) => (
              <circle
                key={`point-${index}`}
                cx={point.x}
                cy={point.y}
                r="4"
                fill="hsl(var(--primary))"
                stroke="hsl(var(--background))"
                strokeWidth="2"
              />
            ))}

            {/* Labels */}
            {categories.map((category, index) => {
              const labelPoint = getGridCoordinates(index, 115);
              return (
                <text
                  key={`label-${index}`}
                  x={labelPoint.x}
                  y={labelPoint.y}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  className="text-xs fill-muted-foreground"
                  fontSize="12"
                >
                  {category.label}
                </text>
              );
            })}
          </svg>

          {/* Legend */}
          <div className="mt-4 grid grid-cols-2 gap-2 text-sm" data-testid="chart-legend">
            {categories.map((category) => (
              <div key={category.key} className="flex justify-between">
                <span className="text-muted-foreground">{category.label}:</span>
                <span className="font-medium">{category.value}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
