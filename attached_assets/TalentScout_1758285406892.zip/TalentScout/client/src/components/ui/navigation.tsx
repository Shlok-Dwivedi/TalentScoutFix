import { Link, useLocation } from "wouter";
import { Home, User, Video, Trophy, Users, Handshake } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Dashboard" },
  { path: "/profile", icon: User, label: "Profile" },
  { path: "/video-analysis", icon: Video, label: "Analysis" },
  { path: "/leaderboard", icon: Trophy, label: "Leaderboard" },
  { path: "/coaching", icon: Users, label: "Coaching" },
  { path: "/sponsorship", icon: Handshake, label: "Sponsors" },
];

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 lg:top-0 lg:bottom-auto lg:border-b lg:border-t-0" data-testid="main-navigation">
      <div className="flex justify-around lg:justify-center lg:space-x-8 py-3 lg:py-4">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location === path;
          return (
            <Link
              key={path}
              href={path}
              className={`flex flex-col lg:flex-row items-center transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid={`nav-link-${label.toLowerCase()}`}
            >
              <Icon className="w-5 h-5 lg:mr-2" />
              <span className="text-xs lg:text-sm mt-1 lg:mt-0">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
