import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Share2, 
  Star, 
  Trophy, 
  TrendingUp, 
  Calendar,
  Brain,
  Play
} from "lucide-react";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  sport: string;
  skillLevel: string;
  avatar: string;
  bio: string;
}

interface PerformanceMetrics {
  speed: number;
  technique: number;
  endurance: number;
  power: number;
  balance: number;
  agility: number;
}

interface VideoAnalysis {
  id: string;
  title: string;
  thumbnailUrl: string;
  overallScore: number;
  createdAt: string;
}

interface Badge {
  id: string;
  title: string;
  badgeType: string;
  icon: string;
}

export default function AthleteProfile() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users/current'],
  });

  const { data: metrics, isLoading: metricsLoading } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/users', user?.id, 'metrics'],
    enabled: !!user?.id,
  });

  const { data: videos, isLoading: videosLoading } = useQuery<VideoAnalysis[]>({
    queryKey: ['/api/users', user?.id, 'videos'],
    enabled: !!user?.id,
  });

  const { data: badges, isLoading: badgesLoading } = useQuery<Badge[]>({
    queryKey: ['/api/users', user?.id, 'badges'],
    enabled: !!user?.id,
  });

  if (userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-profile">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="error-profile">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Failed to load profile data</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto pt-8" data-testid="profile-main">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div className="flex items-center mb-4 lg:mb-0">
          <img 
            src={user.avatar} 
            alt="Athlete profile" 
            className="w-20 h-20 rounded-full border-4 border-primary mr-4"
            data-testid="profile-avatar"
          />
          <div>
            <h1 className="text-2xl lg:text-3xl font-heading font-bold" data-testid="profile-name">
              {user.firstName} {user.lastName}
            </h1>
            <p className="text-muted-foreground" data-testid="profile-sport">
              {user.sport} • {user.skillLevel}
            </p>
            <div className="flex items-center mt-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star}
                    className={`w-4 h-4 ${star <= 4 ? 'text-accent fill-current' : 'text-muted-foreground'}`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground ml-2">4.2/5.0</span>
            </div>
          </div>
        </div>
        <Button className="gradient-bg neon-glow" data-testid="button-share-portfolio">
          <Share2 className="w-4 h-4 mr-2" />
          Share Portfolio
        </Button>
      </div>

      {/* Profile Bio */}
      {user.bio && (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <p className="text-muted-foreground" data-testid="profile-bio">{user.bio}</p>
          </CardContent>
        </Card>
      )}

      {/* Profile Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="progress" data-testid="tab-progress">Progress</TabsTrigger>
          <TabsTrigger value="gallery" data-testid="tab-gallery">Video Gallery</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Achievements & Badges */}
            <div className="lg:col-span-1">
              <h3 className="font-heading font-bold text-lg mb-4">
                <Trophy className="inline w-5 h-5 mr-2" />
                Achievements
              </h3>
              {badgesLoading ? (
                <div className="grid grid-cols-3 gap-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="bg-card rounded-lg p-3 border border-border animate-pulse">
                      <div className="w-6 h-6 bg-muted rounded mx-auto mb-2"></div>
                      <div className="h-3 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-3" data-testid="badges-grid">
                  {badges?.slice(0, 6).map((badge) => (
                    <Card key={badge.id} className="text-center border-accent">
                      <CardContent className="p-3">
                        <div className="text-accent text-xl mb-2">🏆</div>
                        <p className="text-xs font-medium">{badge.title}</p>
                      </CardContent>
                    </Card>
                  ))}
                  {/* Show locked badges if less than 6 */}
                  {Array.from({ length: Math.max(0, 6 - (badges?.length || 0)) }).map((_, i) => (
                    <Card key={`locked-${i}`} className="text-center border-border">
                      <CardContent className="p-3">
                        <div className="text-muted-foreground text-xl mb-2">🔒</div>
                        <p className="text-xs font-medium text-muted-foreground">Locked</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {/* Key Statistics */}
            <div className="lg:col-span-2">
              <h3 className="font-heading font-bold text-lg mb-4">
                📊 Performance Metrics
              </h3>
              {metricsLoading ? (
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-4">
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-8 bg-muted rounded mb-2"></div>
                        <div className="h-2 bg-muted rounded"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-4" data-testid="metrics-grid">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Speed</span>
                        <div className="text-primary">⚡</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.speed || 0}</span>
                      <Progress value={metrics?.speed || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Technique</span>
                        <div className="text-accent">⚙️</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.technique || 0}</span>
                      <Progress value={metrics?.technique || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Endurance</span>
                        <div className="text-primary">❤️</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.endurance || 0}</span>
                      <Progress value={metrics?.endurance || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Power</span>
                        <div className="text-accent">💪</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.power || 0}</span>
                      <Progress value={metrics?.power || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Balance</span>
                        <div className="text-primary">⚖️</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.balance || 0}</span>
                      <Progress value={metrics?.balance || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-muted-foreground text-sm">Agility</span>
                        <div className="text-accent">🏃</div>
                      </div>
                      <span className="text-2xl font-bold">{metrics?.agility || 0}</span>
                      <Progress value={metrics?.agility || 0} className="mt-2" />
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Progress Tab */}
        <TabsContent value="progress" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Radar Chart Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Performance Radar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="w-64 h-64 mx-auto bg-muted rounded-full flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="w-12 h-12 text-primary mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">Radar Chart</p>
                    <p className="text-xs text-muted-foreground">Performance Analysis</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Progress Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Recent Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4" data-testid="progress-timeline">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">Speed improvement: +5 points</p>
                      <p className="text-xs text-muted-foreground">2 days ago</p>
                    </div>
                    <span className="text-accent text-sm">+5</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-accent rounded-full mr-3"></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">Completed weekly challenge</p>
                      <p className="text-xs text-muted-foreground">1 week ago</p>
                    </div>
                    <Trophy className="w-4 h-4 text-accent" />
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">Technique score: +8 points</p>
                      <p className="text-xs text-muted-foreground">1 week ago</p>
                    </div>
                    <span className="text-accent text-sm">+8</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Video Gallery Tab */}
        <TabsContent value="gallery">
          {videosLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-32 bg-muted rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-muted rounded mb-2"></div>
                    <div className="h-3 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : videos?.length === 0 ? (
            <Card data-testid="empty-video-gallery">
              <CardContent className="pt-6 text-center">
                <Brain className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-medium mb-2">No Video Analyses Yet</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Upload your first training video to get AI-powered performance insights
                </p>
                <Button className="gradient-bg" data-testid="button-upload-video">
                  Upload Video
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="video-gallery">
              {videos?.map((video) => (
                <Card key={video.id} className="card-hover overflow-hidden">
                  <div className="relative">
                    <img 
                      src={video.thumbnailUrl || "https://via.placeholder.com/400x225"} 
                      alt={video.title}
                      className="w-full h-32 object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button size="sm" variant="secondary">
                        <Play className="w-4 h-4 mr-2" />
                        Watch
                      </Button>
                    </div>
                    <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                      AI Analyzed
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">{video.title}</h4>
                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <span>{new Date(video.createdAt).toLocaleDateString()}</span>
                      <div className="flex items-center">
                        <Brain className="w-3 h-3 text-primary mr-1" />
                        <span>AI Score: {video.overallScore}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </main>
  );
}
