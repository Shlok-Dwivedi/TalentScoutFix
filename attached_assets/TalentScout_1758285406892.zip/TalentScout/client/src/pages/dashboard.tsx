import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Trophy, 
  TrendingUp, 
  Calendar, 
  Zap, 
  Star,
  Medal,
  Flame,
  Target,
  Activity,
  RotateCcw,
  Wind
} from "lucide-react";

interface DashboardData {
  user: {
    id: string;
    firstName: string;
    lastName: string;
    sport: string;
    talentScore: number;
    avatar: string;
  };
  metrics: {
    speed: number;
    technique: number;
    endurance: number;
    power: number;
    balance: number;
    agility: number;
  };
  recentAnalyses: Array<{
    id: string;
    title: string;
    overallScore: number;
    createdAt: string;
  }>;
  activeChallenges: Array<{
    challengeId: string;
    progress: number;
  }>;
  upcomingSessions: Array<{
    id: string;
    scheduledAt: string;
    sessionType: string;
  }>;
  badges: Array<{
    id: string;
    title: string;
    badgeType: string;
    icon: string;
  }>;
}

export default function Dashboard() {
  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard', 'current-user'],
    enabled: true,
  });

  const { data: challenges } = useQuery({
    queryKey: ['/api/challenges'],
  });

  const { data: leaderboard } = useQuery({
    queryKey: ['/api/leaderboard'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-dashboard">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="error-dashboard">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Failed to load dashboard data</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { user, metrics } = dashboardData;
  const currentChallenge = challenges?.[0];
  const userProgress = dashboardData.activeChallenges[0];

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto" data-testid="dashboard-main">
      {/* Hero Section with Circular Scorecard */}
      <div className="pt-8 mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
          <div>
            <h1 className="text-2xl lg:text-4xl font-heading font-bold mb-2" data-testid="welcome-heading">
              Welcome back, <span className="gradient-text">{user.firstName} {user.lastName}</span>
            </h1>
            <p className="text-muted-foreground">Your performance summary this week</p>
          </div>
          <div className="flex items-center space-x-4 mt-4 lg:mt-0">
            <div className="relative">
              <i className="fas fa-bell text-xl text-muted-foreground"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full"></span>
            </div>
            <img 
              src={user.avatar} 
              alt="Athlete avatar" 
              className="w-10 h-10 rounded-full border-2 border-primary"
              data-testid="user-avatar"
            />
          </div>
        </div>

        {/* Circular Scorecard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="relative w-64 h-64 mx-auto" data-testid="talent-score-circle">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle className="text-muted" strokeWidth="8" stroke="currentColor" fill="transparent" r="40" cx="50" cy="50" />
                <circle 
                  className="progress-ring__circle text-primary" 
                  strokeWidth="8" 
                  strokeDasharray="251.2" 
                  strokeDashoffset={251.2 - (251.2 * user.talentScore) / 100}
                  strokeLinecap="round" 
                  stroke="currentColor" 
                  fill="transparent" 
                  r="40" 
                  cx="50" 
                  cy="50" 
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-5xl font-bold font-heading gradient-text number-roll" data-testid="talent-score">
                  {user.talentScore}
                </span>
                <span className="text-muted-foreground text-sm">Talent Score</span>
                <span className="text-xs text-accent mt-1">
                  <TrendingUp className="inline w-3 h-3 mr-1" />
                  +15% from last week
                </span>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            <Card className="card-hover" data-testid="stat-sessions">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">This Week</span>
                  <Activity className="w-4 h-4 text-primary" />
                </div>
                <span className="text-2xl font-bold">12</span>
                <p className="text-xs text-muted-foreground">Training Sessions</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover" data-testid="stat-best-score">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Best Score</span>
                  <Star className="w-4 h-4 text-accent" />
                </div>
                <span className="text-2xl font-bold">{metrics.power}</span>
                <p className="text-xs text-muted-foreground">Power Rating</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover" data-testid="stat-rank">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Rank</span>
                  <Medal className="w-4 h-4 text-accent" />
                </div>
                <span className="text-2xl font-bold">#3</span>
                <p className="text-xs text-muted-foreground">Local Leaderboard</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover" data-testid="stat-streak">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Streak</span>
                  <Flame className="w-4 h-4 text-primary" />
                </div>
                <span className="text-2xl font-bold">7</span>
                <p className="text-xs text-muted-foreground">Days Active</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Weekly Challenge CTA */}
      {currentChallenge && (
        <div className="mb-8">
          <Card className="neon-glow" data-testid="weekly-challenge">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="font-heading font-bold text-xl mb-2">
                    <Zap className="inline w-5 h-5 mr-2" />
                    {currentChallenge.title}
                  </h2>
                  <p className="text-muted-foreground mb-4">{currentChallenge.description}</p>
                </div>
                <Badge variant="secondary" className="pulse-neon" data-testid="challenge-deadline">
                  2 days left
                </Badge>
              </div>
              <Progress value={userProgress?.progress || 0} className="mb-4" data-testid="challenge-progress" />
              <div className="flex justify-between text-sm text-muted-foreground mb-6">
                <span>3/5 drills completed</span>
                <span>{userProgress?.progress || 0}% progress</span>
              </div>
              <Button className="w-full gradient-bg neon-glow" data-testid="button-continue-challenge">
                <Zap className="w-4 h-4 mr-2" />
                Continue Challenge
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Grid Layout: Leaderboard + Sessions + Drills */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* Leaderboard Snapshot */}
        <Card data-testid="leaderboard-snapshot">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center">
                <Trophy className="w-5 h-5 mr-2" />
                Local Leaderboard
              </CardTitle>
              <Button variant="link" size="sm" data-testid="link-view-all-leaderboard">
                View all →
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaderboard?.slice(0, 3).map((athlete, index) => (
                <div key={athlete.id} className="flex items-center py-2" data-testid={`leaderboard-rank-${index + 1}`}>
                  <span className={`text-sm w-8 ${index === 0 ? 'text-accent font-bold' : 'text-muted-foreground'}`}>
                    #{index + 1}
                  </span>
                  <img 
                    src={athlete.avatar || "https://via.placeholder.com/32"} 
                    className="w-8 h-8 rounded-full mr-3" 
                    alt={`${athlete.firstName} avatar`}
                  />
                  <div className="flex-1">
                    <span className="font-medium">{athlete.firstName} {athlete.lastName}</span>
                    <div className="flex items-center mt-1">
                      <Star className="w-3 h-3 text-accent mr-1" />
                      <span className="text-xs text-muted-foreground">{athlete.sport}</span>
                    </div>
                  </div>
                  <span className="text-primary font-bold">{athlete.talentScore}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Sessions */}
        <Card data-testid="upcoming-sessions">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Next Session
              </CardTitle>
              <Button variant="link" size="sm" data-testid="link-schedule">
                Schedule →
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="border border-border rounded-lg p-4">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50" 
                  className="w-12 h-12 rounded-full mr-3" 
                  alt="Coach Williams"
                />
                <div className="flex-1">
                  <h3 className="font-medium">Coach Williams</h3>
                  <p className="text-sm text-muted-foreground">Speed & Agility Specialist</p>
                  <div className="flex items-center mt-1">
                    <Star className="w-3 h-3 text-accent mr-1" />
                    <span className="text-xs text-accent">4.9 rating</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">Tomorrow</p>
                  <p className="text-xs text-accent">2:30 PM</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" className="flex-1" data-testid="button-reschedule">
                  Reschedule
                </Button>
                <Button className="flex-1 gradient-bg" data-testid="button-join-session">
                  Join Session
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Micro-Drills Grid */}
        <div className="lg:col-span-2 xl:col-span-1">
          <h2 className="font-heading font-bold text-lg mb-4">
            <Zap className="inline w-5 h-5 mr-2" />
            Quick Drills
          </h2>
          <div className="grid grid-cols-2 gap-3" data-testid="quick-drills-grid">
            <Card className="card-hover cursor-pointer" data-testid="drill-speed-ladder">
              <CardContent className="p-4 flex flex-col items-center text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mb-3">
                  <Activity className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-medium text-sm">Speed Ladder</h3>
                <p className="text-xs text-muted-foreground">5 min</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover cursor-pointer" data-testid="drill-precision">
              <CardContent className="p-4 flex flex-col items-center text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mb-3">
                  <Target className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-medium text-sm">Precision</h3>
                <p className="text-xs text-muted-foreground">7 min</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover cursor-pointer" data-testid="drill-reaction">
              <CardContent className="p-4 flex flex-col items-center text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mb-3">
                  <RotateCcw className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-medium text-sm">Reaction Time</h3>
                <p className="text-xs text-muted-foreground">4 min</p>
              </CardContent>
            </Card>
            
            <Card className="card-hover cursor-pointer" data-testid="drill-endurance">
              <CardContent className="p-4 flex flex-col items-center text-center">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center mb-3">
                  <Wind className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-medium text-sm">Endurance</h3>
                <p className="text-xs text-muted-foreground">12 min</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
