import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import VideoUpload from "@/components/video-upload";
import { 
  Upload, 
  Video, 
  Play, 
  Brain, 
  Save, 
  Share2,
  Settings,
  Zap,
  Target,
  Scale
} from "lucide-react";

interface VideoAnalysis {
  id: string;
  title: string;
  videoUrl: string;
  thumbnailUrl: string;
  technique: number;
  power: number;
  balance: number;
  overallScore: number;
  aiFeedback: string;
  keyArea: string;
  priority: string;
  confidence: number;
  createdAt: string;
}

export default function VideoAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<VideoAnalysis | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['/api/users/current'],
  });

  const { data: recentAnalyses, isLoading: analysesLoading } = useQuery<VideoAnalysis[]>({
    queryKey: ['/api/users', user?.id, 'videos'],
    enabled: !!user?.id,
  });

  const analyzeVideoMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest('POST', '/api/videos/analyze', formData);
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentAnalysis(data);
      setIsAnalyzing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'videos'] });
      toast({
        title: "Analysis Complete",
        description: "Your video has been analyzed successfully!",
      });
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleVideoUpload = async (file: File, title: string, description: string) => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "Please log in to upload videos",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    const formData = new FormData();
    formData.append('video', file);
    formData.append('userId', user.id);
    formData.append('title', title);
    formData.append('description', description);

    analyzeVideoMutation.mutate(formData);
  };

  const latestAnalysis = currentAnalysis || recentAnalyses?.[0];

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto pt-8" data-testid="video-analysis-main">
      <h1 className="text-2xl lg:text-3xl font-heading font-bold mb-8">
        🎥 AI Video Analysis
      </h1>

      {/* Upload Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card data-testid="upload-section">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="w-20 h-20 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-primary-foreground" />
              </div>
              <h2 className="font-heading font-bold text-xl mb-2">Upload Your Performance</h2>
              <p className="text-muted-foreground mb-6">
                Record or upload a video (10-60 seconds) for instant AI feedback
              </p>

              <VideoUpload onUpload={handleVideoUpload} isAnalyzing={isAnalyzing} />

              <div className="text-xs text-muted-foreground space-y-1 mt-4">
                <p>• Supported: MP4, MOV, AVI (max 100MB)</p>
                <p>• Best results: landscape, good lighting, full body visible</p>
                <p>• AI analysis typically takes 30-60 seconds</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Preview */}
        <Card data-testid="analysis-preview">
          <CardHeader>
            <CardTitle className="flex items-center">
              📊 Latest Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isAnalyzing ? (
              <div className="text-center py-8" data-testid="analyzing-state">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <h3 className="font-medium mb-2">Analyzing Your Performance</h3>
                <p className="text-sm text-muted-foreground">
                  Our AI is examining your technique, power, and balance...
                </p>
              </div>
            ) : latestAnalysis ? (
              <div data-testid="latest-analysis">
                {/* Video Thumbnail */}
                <div className="relative mb-4">
                  <img 
                    src={latestAnalysis.thumbnailUrl || "https://via.placeholder.com/400x225"} 
                    alt="Video analysis preview" 
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 rounded-lg flex items-center justify-center">
                    <Button size="sm" className="bg-primary" data-testid="button-play-video">
                      <Play className="w-4 h-4 mr-2" />
                      Play
                    </Button>
                  </div>
                  <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                    AI Analyzed
                  </Badge>
                </div>

                {/* Quick Metrics */}
                <div className="grid grid-cols-3 gap-3" data-testid="quick-metrics">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{latestAnalysis.technique}</div>
                    <div className="text-xs text-muted-foreground">Technique</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent">{latestAnalysis.power}</div>
                    <div className="text-xs text-muted-foreground">Power</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{latestAnalysis.balance}</div>
                    <div className="text-xs text-muted-foreground">Balance</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8" data-testid="no-analysis">
                <Video className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-medium mb-2">No Analyses Yet</h3>
                <p className="text-sm text-muted-foreground">
                  Upload your first video to get started
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Analysis Results */}
      {latestAnalysis && !isAnalyzing && (
        <Card className="mb-8" data-testid="analysis-results">
          <CardHeader>
            <CardTitle className="flex items-center">
              🤖 AI Analysis Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Video Side-by-Side */}
              <div>
                <h4 className="font-medium mb-4 flex items-center">
                  <Play className="w-4 h-4 text-primary mr-2" />
                  Performance Breakdown
                </h4>
                <img 
                  src={latestAnalysis.thumbnailUrl || "https://via.placeholder.com/500x280"} 
                  alt="AI analysis overlay" 
                  className="w-full h-64 object-cover rounded-lg mb-4"
                />
                
                {/* AI Feedback Text */}
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="flex items-center mb-3">
                      <Brain className="w-4 h-4 text-primary mr-2" />
                      <h5 className="font-medium">AI Coach Feedback</h5>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3" data-testid="ai-feedback">
                      {latestAnalysis.aiFeedback}
                    </p>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-accent">Key Focus: {latestAnalysis.keyArea}</span>
                      <span className="text-muted-foreground">Confidence: {latestAnalysis.confidence}%</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Metric Cards */}
              <div className="space-y-4">
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium flex items-center">
                        <Settings className="w-4 h-4 text-primary mr-2" />
                        Technique
                      </span>
                      <span className="text-2xl font-bold text-primary">{latestAnalysis.technique}</span>
                    </div>
                    <Progress value={latestAnalysis.technique} className="mb-2" />
                    <p className="text-xs text-muted-foreground">
                      Form analysis shows excellent body alignment and coordination
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium flex items-center">
                        <Zap className="w-4 h-4 text-accent mr-2" />
                        Power
                      </span>
                      <span className="text-2xl font-bold text-accent">{latestAnalysis.power}</span>
                    </div>
                    <Progress value={latestAnalysis.power} className="mb-2" />
                    <p className="text-xs text-muted-foreground">
                      Strong explosive movement and force generation detected
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium flex items-center">
                        <Scale className="w-4 h-4 text-primary mr-2" />
                        Balance
                      </span>
                      <span className="text-2xl font-bold text-primary">{latestAnalysis.balance}</span>
                    </div>
                    <Progress value={latestAnalysis.balance} className="mb-2" />
                    <p className="text-xs text-muted-foreground">
                      Core stability and weight distribution analysis
                    </p>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-4">
                  <Button variant="outline" className="flex-1" data-testid="button-save-analysis">
                    <Save className="w-4 h-4 mr-2" />
                    Save Analysis
                  </Button>
                  <Button className="flex-1 gradient-bg" data-testid="button-share-results">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share Results
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Analyses */}
      {recentAnalyses && recentAnalyses.length > 1 && (
        <Card data-testid="recent-analyses">
          <CardHeader>
            <CardTitle>Recent Analyses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentAnalyses.slice(1, 4).map((analysis) => (
                <Card key={analysis.id} className="card-hover overflow-hidden">
                  <div className="relative">
                    <img 
                      src={analysis.thumbnailUrl || "https://via.placeholder.com/400x225"} 
                      alt={analysis.title}
                      className="w-full h-32 object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button size="sm" variant="secondary">
                        <Play className="w-4 h-4 mr-2" />
                        View
                      </Button>
                    </div>
                    <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                      Score: {analysis.overallScore}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">{analysis.title}</h4>
                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <span>{new Date(analysis.createdAt).toLocaleDateString()}</span>
                      <div className="flex items-center">
                        <Brain className="w-3 h-3 text-primary mr-1" />
                        <span>AI Score: {analysis.overallScore}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
