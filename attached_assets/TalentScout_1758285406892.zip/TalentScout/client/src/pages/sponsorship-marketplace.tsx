import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Handshake, 
  Search, 
  TrendingUp, 
  DollarSign, 
  UserPlus, 
  Star, 
  Target, 
  Rocket,
  Trophy,
  Heart,
  Users,
  BarChart3
} from "lucide-react";

interface SponsorshipProfile {
  id: string;
  userId: string;
  fundingGoal: number;
  currentFunding: number;
  sponsorCount: number;
  achievements: string[];
  trainingHours: number;
  recentAchievement: string;
  user: {
    id: string;
    firstName: string;
    lastName: string;
    sport: string;
    skillLevel: string;
    talentScore: number;
    avatar: string;
  };
}

export default function SponsorshipMarketplace() {
  const [activeTab, setActiveTab] = useState("athletes");

  const { data: sponsorshipProfiles, isLoading } = useQuery<SponsorshipProfile[]>({
    queryKey: ['/api/sponsorship/profiles'],
  });

  const { data: user } = useQuery({
    queryKey: ['/api/users/current'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-sponsorship">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const featuredAthletes = sponsorshipProfiles?.slice(0, 3) || [];
  const fundingProgress = (profile: SponsorshipProfile) => 
    Math.round((profile.currentFunding / profile.fundingGoal) * 100);

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto pt-8" data-testid="sponsorship-main">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-heading font-bold mb-2">
            🤝 Sponsorship Marketplace
          </h1>
          <p className="text-muted-foreground">Connect with sponsors and support rising talent</p>
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4 lg:mt-0">
          <TabsList>
            <TabsTrigger value="athletes" data-testid="tab-for-athletes">For Athletes</TabsTrigger>
            <TabsTrigger value="sponsors" data-testid="tab-for-sponsors">For Sponsors</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <TabsContent value="athletes">
        {/* Featured Athletes */}
        <div className="mb-8">
          <h2 className="font-heading font-bold text-xl mb-4">⭐ Featured Athletes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="featured-athletes">
            {featuredAthletes.map((profile) => (
              <Card key={profile.id} className="card-hover overflow-hidden">
                <div className="h-32 bg-gradient-to-r from-primary/20 to-accent/20 relative">
                  <img 
                    src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200" 
                    alt="Athletic training"
                    className="w-full h-full object-cover opacity-50"
                  />
                  <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                    Featured
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <img 
                      src={profile.user.avatar} 
                      alt={`${profile.user.firstName} ${profile.user.lastName}`}
                      className="w-12 h-12 rounded-full mr-3"
                    />
                    <div>
                      <h3 className="font-bold">{profile.user.firstName} {profile.user.lastName}</h3>
                      <p className="text-sm text-muted-foreground">{profile.user.sport} • {profile.user.skillLevel}</p>
                      <div className="flex items-center mt-1">
                        <div className="flex text-accent mr-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star key={star} className="w-3 h-3 fill-current" />
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground">5.0 Talent Rating</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Performance Score:</span>
                      <span className="text-accent font-bold">{profile.user.talentScore}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Training Hours/Week:</span>
                      <span>{profile.trainingHours} hours</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Recent Achievement:</span>
                      <span className="text-primary">{profile.recentAchievement}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Funding Goal</span>
                      <span className="text-sm text-accent">
                        ${profile.currentFunding.toLocaleString()} / ${profile.fundingGoal.toLocaleString()}
                      </span>
                    </div>
                    <Progress value={fundingProgress(profile)} className="mb-2" />
                    <p className="text-xs text-muted-foreground">
                      {fundingProgress(profile)}% funded • {profile.sponsorCount} sponsors
                    </p>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1" data-testid={`button-view-profile-${profile.id}`}>
                      View Profile
                    </Button>
                    <Button className="flex-1 gradient-bg neon-glow" data-testid={`button-sponsor-${profile.id}`}>
                      Sponsor Athlete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* All Athletes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="all-athletes">
          {sponsorshipProfiles?.slice(3).map((profile) => (
            <Card key={profile.id} className="card-hover overflow-hidden">
              <div className="h-24 bg-gradient-to-r from-muted to-muted-foreground/20 relative">
                <Badge className="absolute top-2 right-2 bg-muted text-foreground">
                  {fundingProgress(profile)}% Funded
                </Badge>
              </div>
              <CardContent className="p-4">
                <div className="flex items-center mb-3">
                  <img 
                    src={profile.user.avatar} 
                    alt={`${profile.user.firstName} ${profile.user.lastName}`}
                    className="w-10 h-10 rounded-full mr-3"
                  />
                  <div>
                    <h4 className="font-medium">{profile.user.firstName} {profile.user.lastName}</h4>
                    <p className="text-xs text-muted-foreground">{profile.user.sport}</p>
                  </div>
                </div>

                <div className="mb-3">
                  <Progress value={fundingProgress(profile)} className="mb-1" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>${profile.currentFunding.toLocaleString()}</span>
                    <span>${profile.fundingGoal.toLocaleString()}</span>
                  </div>
                </div>

                <Button className="w-full gradient-bg text-sm" data-testid={`button-sponsor-small-${profile.id}`}>
                  Support
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>

      <TabsContent value="sponsors">
        {/* Sponsorship Opportunities */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* For Sponsors */}
          <Card data-testid="for-sponsors-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                💼 For Sponsors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-6">
                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                    <Search className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Discover Talent</h4>
                    <p className="text-sm text-muted-foreground">Find athletes that match your brand values</p>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mr-4">
                    <BarChart3 className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Track Progress</h4>
                    <p className="text-sm text-muted-foreground">Monitor athlete development with AI analytics</p>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                    <Handshake className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Build Partnerships</h4>
                    <p className="text-sm text-muted-foreground">Create meaningful sponsorship relationships</p>
                  </div>
                </div>
              </div>

              <Button className="w-full gradient-bg neon-glow" data-testid="button-become-sponsor">
                Become a Sponsor
              </Button>
            </CardContent>
          </Card>

          {/* For Athletes */}
          <Card data-testid="for-athletes-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                🏃‍♂️ For Athletes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-6">
                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mr-4">
                    <UserPlus className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Create Your Profile</h4>
                    <p className="text-sm text-muted-foreground">Showcase your skills and achievements</p>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                    <DollarSign className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Secure Funding</h4>
                    <p className="text-sm text-muted-foreground">Get support for training, equipment, and travel</p>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mr-4">
                    <Rocket className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium">Accelerate Growth</h4>
                    <p className="text-sm text-muted-foreground">Access premium coaching and resources</p>
                  </div>
                </div>
              </div>

              <Button 
                variant="outline" 
                className="w-full border-2 border-primary text-primary neon-glow"
                data-testid="button-create-athlete-profile"
              >
                Create Athlete Profile
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sponsorship Statistics */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6" data-testid="sponsorship-stats">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold mb-2">2,847</h3>
              <p className="text-muted-foreground">Active Athletes</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold mb-2">456</h3>
              <p className="text-muted-foreground">Active Sponsors</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold mb-2">$1.2M</h3>
              <p className="text-muted-foreground">Total Funding</p>
            </CardContent>
          </Card>
        </div>

        {/* Success Stories */}
        <Card className="mt-8" data-testid="success-stories">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Trophy className="w-5 h-5 mr-2" />
              Success Stories
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center p-4 bg-muted rounded-lg">
                <img 
                  src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60" 
                  alt="Success story athlete"
                  className="w-15 h-15 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-medium">Sarah Chen</h4>
                  <p className="text-sm text-muted-foreground mb-2">Swimming • Olympic Qualifier</p>
                  <p className="text-xs text-primary">"TalentScout sponsorships helped me train full-time and qualify for the Olympics"</p>
                </div>
              </div>

              <div className="flex items-center p-4 bg-muted rounded-lg">
                <img 
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60" 
                  alt="Success story athlete"
                  className="w-15 h-15 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-medium">Marcus Rivera</h4>
                  <p className="text-sm text-muted-foreground mb-2">Track & Field • National Champion</p>
                  <p className="text-xs text-primary">"The support from sponsors allowed me to focus solely on my athletic development"</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </main>
  );
}
