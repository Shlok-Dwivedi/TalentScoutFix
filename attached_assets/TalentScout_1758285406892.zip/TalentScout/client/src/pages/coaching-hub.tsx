import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  Calendar, 
  Star, 
  Clock, 
  MessageCircle, 
  ChevronLeft, 
  ChevronRight,
  Send,
  Video,
  Target,
  Dumbbell,
  Trophy
} from "lucide-react";

interface Coach {
  id: string;
  firstName: string;
  lastName: string;
  specialization: string;
  experience: number;
  rating: number;
  ratePerHour: number;
  athletesCoached: number;
  avatar: string;
  bio: string;
  isAvailable: boolean;
}

interface CoachingSession {
  id: string;
  coachId: string;
  sessionType: string;
  scheduledAt: string;
  duration: number;
  status: string;
  notes: string;
}

export default function CoachingHub() {
  const [selectedCoach, setSelectedCoach] = useState<Coach | null>(null);
  const [sessionForm, setSessionForm] = useState({
    date: '',
    time: 'morning',
    sessionType: '1-on-1',
  });
  const [message, setMessage] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['/api/users/current'],
  });

  const { data: coaches, isLoading: coachesLoading } = useQuery<Coach[]>({
    queryKey: ['/api/coaches'],
  });

  const { data: sessions } = useQuery<CoachingSession[]>({
    queryKey: ['/api/users', user?.id, 'sessions'],
    enabled: !!user?.id,
  });

  const bookSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest('POST', '/api/sessions', sessionData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Session Booked",
        description: "Your coaching session has been scheduled successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'sessions'] });
      setSessionForm({ date: '', time: 'morning', sessionType: '1-on-1' });
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "Failed to book session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleBookSession = () => {
    if (!selectedCoach || !user?.id || !sessionForm.date) {
      toast({
        title: "Missing Information",
        description: "Please select a coach and fill in all session details.",
        variant: "destructive",
      });
      return;
    }

    const sessionData = {
      userId: user.id,
      coachId: selectedCoach.id,
      sessionType: sessionForm.sessionType,
      scheduledAt: new Date(`${sessionForm.date}T10:00:00`).toISOString(),
      duration: 60,
      status: 'scheduled',
    };

    bookSessionMutation.mutate(sessionData);
  };

  // Get recommended coach (highest rated available coach)
  const recommendedCoach = coaches?.find(coach => coach.isAvailable && coach.rating >= 4.8);

  const upcomingSession = sessions?.find(session => session.status === 'scheduled');

  if (coachesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-coaching">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto pt-8" data-testid="coaching-main">
      <h1 className="text-2xl lg:text-3xl font-heading font-bold mb-8">
        👥 Coaching Hub
      </h1>

      {/* AI Coach Recommendation */}
      {recommendedCoach && (
        <Card className="neon-glow mb-8" data-testid="ai-recommendation">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-heading font-bold text-xl">🤖 AI Coach Recommendation</h2>
                <p className="text-muted-foreground">Based on your performance profile and goals</p>
              </div>
              <Button variant="link" className="text-primary text-sm" data-testid="button-view-matching-logic">
                View matching logic
              </Button>
            </div>
            
            <Card className="bg-muted">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <img 
                    src={recommendedCoach.avatar} 
                    alt={`${recommendedCoach.firstName} ${recommendedCoach.lastName}`}
                    className="w-16 h-16 rounded-full mr-4"
                  />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{recommendedCoach.firstName} {recommendedCoach.lastName}</h3>
                    <p className="text-sm text-muted-foreground">{recommendedCoach.specialization}</p>
                    <div className="flex items-center mt-2">
                      <div className="flex text-accent mr-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="w-4 h-4 fill-current" />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {recommendedCoach.rating} • {recommendedCoach.athletesCoached} athletes coached
                      </span>
                    </div>
                  </div>
                  <Button 
                    className="gradient-bg neon-glow" 
                    onClick={() => setSelectedCoach(recommendedCoach)}
                    data-testid="button-book-recommended-session"
                  >
                    Book Session
                  </Button>
                </div>
                <div className="mt-4 pt-4 border-t border-border">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Match Score:</span>
                    <span className="text-accent font-bold">94% Perfect Match</span>
                  </div>
                  <div className="w-full bg-background rounded-full h-2 mt-2">
                    <div className="gradient-bg h-2 rounded-full" style={{ width: '94%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coach Carousel */}
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-heading font-bold text-xl">Available Coaches</h2>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" data-testid="button-coaches-prev">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" data-testid="button-coaches-next">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="coaches-grid">
            {coaches?.slice(0, 4).map((coach) => (
              <Card key={coach.id} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start mb-4">
                    <img 
                      src={coach.avatar} 
                      alt={`${coach.firstName} ${coach.lastName}`}
                      className="w-15 h-15 rounded-full mr-4"
                    />
                    <div className="flex-1">
                      <h3 className="font-bold">{coach.firstName} {coach.lastName}</h3>
                      <p className="text-sm text-muted-foreground">{coach.specialization}</p>
                      <div className="flex items-center mt-2">
                        <div className="flex text-accent mr-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={star} 
                              className={`w-3 h-3 ${star <= Math.floor(coach.rating) ? 'fill-current' : ''}`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground">{coach.rating}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Experience:</span>
                      <span>{coach.experience} years</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Athletes:</span>
                      <span>{coach.athletesCoached} coached</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Rate:</span>
                      <span className="text-accent">${coach.ratePerHour}/hour</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1" data-testid={`button-view-profile-${coach.id}`}>
                      View Profile
                    </Button>
                    <Button 
                      className="flex-1 gradient-bg" 
                      onClick={() => setSelectedCoach(coach)}
                      data-testid={`button-book-${coach.id}`}
                    >
                      Book
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Session Scheduler & Chat */}
        <div className="space-y-6">
          {/* Session Scheduler */}
          <Card data-testid="session-scheduler">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule Session
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="session-date">Select Date</Label>
                  <Input 
                    id="session-date"
                    type="date" 
                    value={sessionForm.date}
                    onChange={(e) => setSessionForm(prev => ({ ...prev, date: e.target.value }))}
                    data-testid="input-session-date"
                  />
                </div>
                
                <div>
                  <Label htmlFor="session-time">Preferred Time</Label>
                  <Select 
                    value={sessionForm.time} 
                    onValueChange={(value) => setSessionForm(prev => ({ ...prev, time: value }))}
                  >
                    <SelectTrigger data-testid="select-session-time">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (8AM - 12PM)</SelectItem>
                      <SelectItem value="afternoon">Afternoon (12PM - 5PM)</SelectItem>
                      <SelectItem value="evening">Evening (5PM - 8PM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="session-type">Session Type</Label>
                  <Select 
                    value={sessionForm.sessionType} 
                    onValueChange={(value) => setSessionForm(prev => ({ ...prev, sessionType: value }))}
                  >
                    <SelectTrigger data-testid="select-session-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-on-1">1-on-1 Training</SelectItem>
                      <SelectItem value="video-analysis">Video Analysis</SelectItem>
                      <SelectItem value="technique-review">Technique Review</SelectItem>
                      <SelectItem value="goal-setting">Goal Setting</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {selectedCoach ? (
                  <Button 
                    className="w-full gradient-bg" 
                    onClick={handleBookSession}
                    disabled={bookSessionMutation.isPending}
                    data-testid="button-book-session"
                  >
                    {bookSessionMutation.isPending ? 'Booking...' : `Book with ${selectedCoach.firstName}`}
                  </Button>
                ) : (
                  <Button className="w-full" variant="outline" disabled data-testid="button-find-slots">
                    Select a coach first
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Session */}
          {upcomingSession && (
            <Card data-testid="upcoming-session-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2" />
                  Next Session
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-3">
                    <Users className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-medium">{upcomingSession.sessionType}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(upcomingSession.scheduledAt).toLocaleDateString()} at{' '}
                      {new Date(upcomingSession.scheduledAt).toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" className="flex-1" data-testid="button-reschedule-session">
                    Reschedule
                  </Button>
                  <Button className="flex-1 gradient-bg" data-testid="button-join-upcoming-session">
                    <Video className="w-4 h-4 mr-2" />
                    Join
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Chat Thread Preview */}
          <Card data-testid="chat-preview">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageCircle className="w-5 h-5 mr-2" />
                Recent Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-4">
                <div className="flex items-start">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" 
                    alt="Coach avatar" 
                    className="w-8 h-8 rounded-full mr-2"
                  />
                  <div className="bg-muted rounded-lg p-3 max-w-xs">
                    <p className="text-sm">Great progress on your sprint form! Focus on maintaining that drive phase we worked on.</p>
                    <span className="text-xs text-muted-foreground">Coach Thompson • 2h ago</span>
                  </div>
                </div>
                
                <div className="flex items-start justify-end">
                  <div className="bg-primary rounded-lg p-3 max-w-xs">
                    <p className="text-sm text-primary-foreground">Thanks! I felt the difference during today's session. Ready for tomorrow's workout.</p>
                    <span className="text-xs text-primary-foreground opacity-75">You • 1h ago</span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-2">
                <Input 
                  placeholder="Type a message..." 
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="flex-1 text-sm"
                  data-testid="input-chat-message"
                />
                <Button size="sm" className="bg-primary" data-testid="button-send-message">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Training Focus Areas */}
          <Card data-testid="training-focus">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Focus Areas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Badge variant="secondary" className="w-full justify-start p-2">
                  <Dumbbell className="w-4 h-4 mr-2" />
                  Strength Training
                </Badge>
                <Badge variant="secondary" className="w-full justify-start p-2">
                  <Target className="w-4 h-4 mr-2" />
                  Technique Refinement
                </Badge>
                <Badge variant="secondary" className="w-full justify-start p-2">
                  <Trophy className="w-4 h-4 mr-2" />
                  Competition Prep
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
