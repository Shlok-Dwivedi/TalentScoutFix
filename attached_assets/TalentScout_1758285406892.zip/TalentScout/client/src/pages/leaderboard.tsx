import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Crown, 
  Medal, 
  Star, 
  Clock, 
  Users, 
  Zap,
  Target,
  Flame,
  Filter
} from "lucide-react";

interface LeaderboardUser {
  id: string;
  firstName: string;
  lastName: string;
  sport: string;
  skillLevel: string;
  talentScore: number;
  avatar: string;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  participants: number;
  prizePool: number;
  endDate: string;
}

export default function Leaderboard() {
  const [activeFilter, setActiveFilter] = useState<'global' | 'local' | 'age'>('global');

  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery<LeaderboardUser[]>({
    queryKey: ['/api/leaderboard', { filter: activeFilter, limit: 10 }],
  });

  const { data: challenges } = useQuery<Challenge[]>({
    queryKey: ['/api/challenges'],
  });

  const { data: user } = useQuery({
    queryKey: ['/api/users/current'],
  });

  const activeChallenge = challenges?.[0];
  const userRank = leaderboard?.findIndex(u => u.id === user?.id) + 1 || 0;

  const handleFilterChange = (filter: 'global' | 'local' | 'age') => {
    setActiveFilter(filter);
  };

  if (leaderboardLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-leaderboard">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <main className="pb-20 lg:pt-20 lg:pb-8 px-4 lg:px-8 max-w-7xl mx-auto pt-8" data-testid="leaderboard-main">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <h1 className="text-2xl lg:text-3xl font-heading font-bold mb-4 lg:mb-0">
          🏆 Leaderboards & Challenges
        </h1>
        
        {/* Filters */}
        <div className="flex space-x-2" data-testid="leaderboard-filters">
          <Button 
            variant={activeFilter === 'global' ? 'default' : 'outline'}
            onClick={() => handleFilterChange('global')}
            className={activeFilter === 'global' ? 'gradient-bg' : ''}
            data-testid="filter-global"
          >
            <Filter className="w-4 h-4 mr-2" />
            Global
          </Button>
          <Button 
            variant={activeFilter === 'local' ? 'default' : 'outline'}
            onClick={() => handleFilterChange('local')}
            className={activeFilter === 'local' ? 'gradient-bg' : ''}
            data-testid="filter-local"
          >
            Local
          </Button>
          <Button 
            variant={activeFilter === 'age' ? 'default' : 'outline'}
            onClick={() => handleFilterChange('age')}
            className={activeFilter === 'age' ? 'gradient-bg' : ''}
            data-testid="filter-age"
          >
            Age Group
          </Button>
        </div>
      </div>

      {/* Active Challenge Banner */}
      {activeChallenge && (
        <Card className="gradient-bg text-primary-foreground mb-8" data-testid="active-challenge-banner">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="text-xl font-heading font-bold mb-2">
                  <Zap className="inline w-5 h-5 mr-2" />
                  {activeChallenge.title}
                </h2>
                <p className="mb-4 opacity-90">{activeChallenge.description}</p>
                <div className="flex items-center space-x-4 text-sm">
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    2 days left
                  </span>
                  <span className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    {activeChallenge.participants.toLocaleString()} participants
                  </span>
                  <span className="flex items-center">
                    <Trophy className="w-4 h-4 mr-1" />
                    ${activeChallenge.prizePool} prize pool
                  </span>
                </div>
              </div>
              <Button 
                className="bg-primary-foreground text-primary font-bold px-6 py-3 rounded-lg mt-4 lg:mt-0 pulse-neon"
                data-testid="button-join-challenge"
              >
                Join Challenge
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Leaderboard */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>
                {activeFilter === 'global' ? 'Global Rankings' : 
                 activeFilter === 'local' ? 'Local Rankings' : 'Age Group Rankings'}
              </CardTitle>
              <p className="text-sm text-muted-foreground">Top performers this month</p>
            </CardHeader>
            
            <CardContent className="p-0">
              <div className="divide-y divide-border" data-testid="leaderboard-list">
                {leaderboard?.map((athlete, index) => (
                  <div 
                    key={athlete.id} 
                    className={`p-4 ${
                      index === 0 ? 'bg-gradient-to-r from-accent/10 to-transparent' :
                      index === 1 ? 'bg-gradient-to-r from-primary/10 to-transparent' :
                      athlete.id === user?.id ? 'bg-accent/10 border-l-4 border-l-accent' : ''
                    }`}
                    data-testid={`leaderboard-rank-${index + 1}`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 text-primary-foreground font-bold ${
                        index === 0 ? 'bg-accent' :
                        index === 1 ? 'bg-primary' :
                        index === 2 ? 'bg-muted' : 'bg-muted'
                      }`}>
                        {index + 1}
                      </div>
                      
                      <img 
                        src={athlete.avatar || "https://via.placeholder.com/50"} 
                        alt={`${athlete.firstName} avatar`}
                        className="w-12 h-12 rounded-full mr-4"
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-center">
                          <h4 className="font-bold">{athlete.firstName} {athlete.lastName}</h4>
                          {index === 0 && <Crown className="w-4 h-4 text-accent ml-2" />}
                          {index === 1 && <Medal className="w-4 h-4 text-primary ml-2" />}
                          {index === 2 && <Star className="w-4 h-4 text-accent ml-2" />}
                        </div>
                        <p className="text-sm text-muted-foreground">{athlete.sport} • {athlete.skillLevel}</p>
                        {index < 3 && (
                          <div className="flex items-center mt-1">
                            <Badge variant="secondary" className="text-xs mr-2">
                              {index === 0 ? 'Champion' : index === 1 ? 'Elite' : 'Rising Star'}
                            </Badge>
                          </div>
                        )}
                      </div>
                      
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${
                          index === 0 ? 'text-accent' : 
                          index === 1 ? 'text-primary' : 
                          'text-foreground'
                        }`}>
                          {athlete.talentScore}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          +{Math.floor(Math.random() * 10) + 1} this week
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar: Challenges & Recognition */}
        <div className="space-y-6">
          {/* Weekly Challenges */}
          <Card data-testid="challenges-sidebar">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Active Challenges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Card className="border border-border">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-sm">Speed Demon Week</h4>
                      <Badge className="bg-primary text-primary-foreground text-xs">Hot</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">
                      Complete 10 speed drills with 90%+ accuracy
                    </p>
                    <Progress value={60} className="mb-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>6/10 completed</span>
                      <span>2 days left</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-border">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-sm">Technique Tuesday</h4>
                      <Badge variant="secondary" className="text-xs">New</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">
                      Perfect your form in 3 different exercises
                    </p>
                    <Button 
                      variant="outline" 
                      className="w-full text-primary border-primary neon-glow"
                      data-testid="button-join-technique-challenge"
                    >
                      Join Challenge
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          {/* Recognition Tags */}
          <Card data-testid="achievements-sidebar">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Star className="w-5 h-5 mr-2" />
                Recent Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                    <Zap className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Speed Improvement</h4>
                    <p className="text-xs text-muted-foreground">+15% faster this month</p>
                  </div>
                </div>

                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                    <Flame className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">7-Day Streak</h4>
                    <p className="text-xs text-muted-foreground">Consistent daily training</p>
                  </div>
                </div>

                <div className="flex items-center p-3 bg-muted rounded-lg">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                    <Trophy className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Top 3 Finish</h4>
                    <p className="text-xs text-muted-foreground">Local leaderboard ranking</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* User's Current Position */}
          {userRank > 0 && (
            <Card className="border-accent" data-testid="user-position">
              <CardHeader>
                <CardTitle className="flex items-center text-accent">
                  <Medal className="w-5 h-5 mr-2" />
                  Your Position
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent mb-2">#{userRank}</div>
                  <p className="text-sm text-muted-foreground mb-4">
                    out of {leaderboard?.length} athletes
                  </p>
                  <Button className="w-full gradient-bg" data-testid="button-improve-rank">
                    Improve Ranking
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </main>
  );
}
