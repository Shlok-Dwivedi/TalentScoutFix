# Overview

This is an athletic performance analysis platform that combines AI-powered video analysis with social features, coaching, and sponsorship opportunities. The application allows athletes to upload training videos for detailed performance analysis, compete on leaderboards, connect with coaches, and seek sponsorship opportunities. The platform uses advanced pose estimation and biomechanical analysis to provide actionable feedback for athletic improvement.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Full-Stack Architecture
The application follows a modern full-stack architecture with a clear separation between client and server components:

**Frontend**: React with TypeScript, using Vite as the build tool and development server. The frontend is built as a single-page application (SPA) with client-side routing using Wouter.

**Backend**: Express.js server with TypeScript, serving both API endpoints and static assets. The server handles video processing, AI analysis, and data management.

**Database**: PostgreSQL with Drizzle ORM for type-safe database operations and migrations.

## Component Architecture
The frontend uses a component-based architecture with:
- **UI Components**: Comprehensive design system built on Radix UI primitives with custom styling via Tailwind CSS
- **Page Components**: Route-specific components for different application views (Dashboard, Video Analysis, Coaching, etc.)
- **Custom Components**: Specialized components like video upload handlers and performance charts
- **Navigation**: Fixed navigation system supporting both mobile and desktop layouts

## Video Processing Pipeline
The application implements a sophisticated video analysis system with multiple fallback methods:
- **Primary Analysis**: MediaPipe-based pose estimation for biomechanical analysis
- **Fallback Analysis**: OpenAI Vision API for video frame analysis when MediaPipe is unavailable
- **Basic Fallback**: Simple analysis when both advanced methods fail
- **File Processing**: Multer-based file upload system with validation and storage management

## Data Models
The database schema supports a comprehensive athletic platform with:
- **User Management**: Athletes with profiles, performance metrics, and talent scoring
- **Video Analysis**: Storage of analysis results with detailed performance breakdowns
- **Social Features**: Leaderboards, challenges, and progress tracking
- **Coaching System**: Coach profiles, session scheduling, and interaction tracking
- **Sponsorship Platform**: Funding goals, achievements, and sponsor matching

## State Management
The application uses React Query for server state management, providing:
- Automatic caching and background updates
- Optimistic updates for better user experience
- Error handling and retry logic
- Real-time data synchronization

## Styling and Design
The frontend implements a dark-themed design system using:
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **CSS Variables**: Dynamic theming support with consistent color schemes
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Component Variants**: Class Variance Authority for consistent component styling

## Development Workflow
The project supports modern development practices with:
- **Hot Module Replacement**: Vite-based development server with instant updates
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Build Optimization**: Separate build processes for client and server code
- **Environment Management**: Support for development and production configurations

# External Dependencies

## Database and ORM
- **PostgreSQL**: Primary database for data persistence
- **Drizzle ORM**: Type-safe database operations and schema management
- **Neon Database**: Serverless PostgreSQL hosting solution

## AI and Machine Learning
- **OpenAI API**: Backup video analysis using GPT-5 vision capabilities
- **MediaPipe**: Primary pose estimation and biomechanical analysis (Python integration)
- **Python Integration**: Child process execution for MediaPipe analysis scripts

## UI Framework and Styling
- **React**: Component-based frontend framework
- **Radix UI**: Accessible primitive components for complex UI elements
- **Tailwind CSS**: Utility-first styling with custom design tokens
- **Lucide React**: Icon library for consistent visual elements

## File Processing and Storage
- **Multer**: Multipart form data handling for video uploads
- **Node.js File System**: Local file storage and processing
- **Express.js**: Web server framework with middleware support

## Development and Build Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking across the entire codebase
- **ESBuild**: Fast JavaScript bundling for production builds
- **Wouter**: Lightweight client-side routing solution

## Form and State Management
- **React Hook Form**: Form validation and state management
- **React Query**: Server state management and caching
- **Zod**: Runtime type validation and schema definition

## Session and Authentication
- **Express Session**: Session management with PostgreSQL storage
- **Connect PG Simple**: PostgreSQL session store adapter