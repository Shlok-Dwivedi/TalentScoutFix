import { spawn } from 'child_process';
import path from 'path';
import { analyzeVideoFrames, generateTrainingRecommendations, type VideoAnalysisResult } from './openai';

export interface EnhancedAnalysisResult extends VideoAnalysisResult {
  pose_data?: {
    total_frames_processed: number;
    successful_detections: number;
    detection_rate: number;
    recommendations: string[];
    movement_consistency: number;
  };
  analysis_method: 'mediapipe' | 'openai' | 'fallback';
}

export class AnalysisService {
  async analyzeVideo(videoPath: string, sport: string = 'general', frames?: string[]): Promise<EnhancedAnalysisResult> {
    try {
      // First try MediaPipe analysis
      const mediapipeResult = await this.analyzeWithMediaPipe(videoPath, sport);
      return {
        ...mediapipeResult,
        analysis_method: 'mediapipe'
      };
    } catch (mediapipeError) {
      console.log('MediaPipe analysis failed, trying OpenAI:', mediapipeError.message);
      
      try {
        // Fallback to OpenAI if available and frames provided
        if (frames && frames.length > 0) {
          const openaiResult = await analyzeVideoFrames(frames, sport);
          return {
            ...openaiResult,
            analysis_method: 'openai'
          };
        }
        throw new Error('No frames available for OpenAI analysis');
      } catch (openaiError) {
        console.log('OpenAI analysis also failed, using fallback:', openaiError.message);
        
        // Provide basic fallback analysis
        return this.getFallbackAnalysis(sport);
      }
    }
  }

  private async analyzeWithMediaPipe(videoPath: string, sport: string): Promise<EnhancedAnalysisResult> {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(process.cwd(), 'server/services/mediapipe_analyzer.py');
      const fullVideoPath = path.join(process.cwd(), videoPath.replace(/^\//, ''));
      
      const python = spawn('python3', [scriptPath, fullVideoPath, sport]);
      
      // Add timeout protection (60 seconds)
      const timeout = setTimeout(() => {
        python.kill('SIGTERM');
      }, 60000);
      
      let stdout = '';
      let stderr = '';
      
      python.stdout.on('data', (data) => {
        stdout += data.toString();
      });
      
      python.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      python.on('close', (code) => {
        clearTimeout(timeout);
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            if (result.error) {
              reject(new Error(result.error));
            } else {
              resolve(result as EnhancedAnalysisResult);
            }
          } catch (parseError) {
            reject(new Error(`Failed to parse MediaPipe results: ${parseError.message}`));
          }
        } else {
          reject(new Error(`MediaPipe process failed with code ${code}: ${stderr}`));
        }
      });
      
      python.on('error', (error) => {
        reject(new Error(`Failed to spawn MediaPipe process: ${error.message}`));
      });
    });
  }

  private getFallbackAnalysis(sport: string): EnhancedAnalysisResult {
    // Provide basic analysis when both MediaPipe and OpenAI fail
    const baseScore = 75; // Conservative middle-ground score
    
    return {
      technique: baseScore,
      power: baseScore,
      balance: baseScore,
      overallScore: baseScore,
      feedback: `Basic analysis completed for ${sport}. For detailed performance insights, ensure good video quality with clear visibility of the athlete. Consider improving lighting and camera angle for more accurate analysis.`,
      keyArea: 'Form and technique',
      priority: 'Medium',
      confidence: 50,
      analysis_method: 'fallback',
      pose_data: {
        total_frames_processed: 0,
        successful_detections: 0,
        detection_rate: 0,
        recommendations: [
          'Ensure good lighting and clear camera view',
          'Record from multiple angles if possible',
          'Focus on consistent practice and form',
          'Consider working with a qualified coach'
        ],
        movement_consistency: 0
      }
    };
  }

  async generateRecommendations(
    userGoals: string,
    currentPerformance: EnhancedAnalysisResult,
    sport: string
  ): Promise<{ recommendations: string[]; focus: string; timeline: string }> {
    try {
      // Try to use OpenAI for recommendations if available
      return await generateTrainingRecommendations(userGoals, currentPerformance, sport);
    } catch (error) {
      // Fallback to basic recommendations
      const focus = currentPerformance.keyArea || 'Overall technique';
      const recommendations: string[] = [];
      
      // Add specific recommendations based on analysis results
      if (currentPerformance.pose_data?.recommendations) {
        recommendations.push(...currentPerformance.pose_data.recommendations);
      }
      
      // Add general recommendations based on scores
      if (currentPerformance.technique < 80) {
        recommendations.push('Focus on technical drills and form practice');
        recommendations.push('Record yourself regularly to monitor progress');
      }
      
      if (currentPerformance.balance < 80) {
        recommendations.push('Include balance and stability training');
        recommendations.push('Strengthen core muscles for better control');
      }
      
      if (currentPerformance.power < 80) {
        recommendations.push('Add explosive power exercises to your routine');
        recommendations.push('Work on full range of motion movements');
      }
      
      // Default recommendations if none generated
      if (recommendations.length === 0) {
        recommendations.push(
          'Maintain consistent training schedule',
          'Focus on progressive skill development',
          'Seek feedback from experienced coaches',
          'Monitor and track your progress regularly'
        );
      }
      
      return {
        recommendations,
        focus,
        timeline: '4-8 weeks for noticeable improvements'
      };
    }
  }
}

export const analysisService = new AnalysisService();