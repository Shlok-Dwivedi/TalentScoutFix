import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = process.env.OPENAI_API_KEY ? new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
}) : null;

export interface VideoAnalysisResult {
  technique: number;
  power: number;
  balance: number;
  overallScore: number;
  feedback: string;
  keyArea: string;
  priority: 'Low' | 'Medium' | 'High';
  confidence: number;
}

export async function analyzeVideoFrames(base64Frames: string[], sport: string): Promise<VideoAnalysisResult> {
  // If OpenAI is not available, throw an error to use fallback
  if (!openai) {
    throw new Error('OpenAI API key not available');
  }
  
  try {
    const messages = [
      {
        role: "system" as const,
        content: `You are an expert sports performance analyst specializing in ${sport}. Analyze the video frames and provide detailed performance feedback. Respond with JSON in this exact format: {
          "technique": number (0-100),
          "power": number (0-100), 
          "balance": number (0-100),
          "overallScore": number (0-100),
          "feedback": "detailed feedback string",
          "keyArea": "main area for improvement",
          "priority": "Low|Medium|High",
          "confidence": number (0-100)
        }`
      },
      {
        role: "user" as const,
        content: [
          {
            type: "text" as const,
            text: `Analyze this ${sport} performance video. Focus on technique, power output, and balance. Provide specific, actionable feedback for improvement.`
          },
          ...base64Frames.slice(0, 3).map(frame => ({
            type: "image_url" as const,
            image_url: {
              url: `data:image/jpeg;base64,${frame}`
            }
          }))
        ]
      }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
      response_format: { type: "json_object" },
      max_completion_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Validate and ensure all required fields are present
    return {
      technique: Math.max(0, Math.min(100, result.technique || 75)),
      power: Math.max(0, Math.min(100, result.power || 75)),
      balance: Math.max(0, Math.min(100, result.balance || 75)),
      overallScore: Math.max(0, Math.min(100, result.overallScore || 75)),
      feedback: result.feedback || "Analysis completed successfully.",
      keyArea: result.keyArea || "Form and technique",
      priority: ['Low', 'Medium', 'High'].includes(result.priority) ? result.priority : 'Medium',
      confidence: Math.max(0, Math.min(100, result.confidence || 85)),
    };
  } catch (error) {
    console.error('OpenAI analysis error:', error);
    
    // Provide fallback analysis if OpenAI fails
    return {
      technique: 75,
      power: 75,
      balance: 75,
      overallScore: 75,
      feedback: "Video analysis completed. Focus on maintaining consistent form throughout your movement.",
      keyArea: "Overall technique",
      priority: 'Medium',
      confidence: 70,
    };
  }
}

export async function generateTrainingRecommendations(
  userGoals: string,
  currentPerformance: any,
  sport: string
): Promise<{ recommendations: string[]; focus: string; timeline: string }> {
  // If OpenAI is not available, provide basic recommendations
  if (!openai) {
    return {
      recommendations: [
        "Focus on consistent practice and form improvement",
        "Incorporate strength and conditioning exercises",
        "Work with a qualified coach for personalized guidance",
        "Record and review your technique regularly"
      ],
      focus: "Fundamentals and consistency",
      timeline: "4-6 weeks for initial improvements"
    };
  }
  
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return {
      recommendations: result.recommendations || [
        "Focus on consistent practice and form improvement",
        "Work on sport-specific drills and techniques",
        "Incorporate strength and conditioning"
      ],
      focus: result.focus || currentPerformance.keyArea || "Overall technique",
      timeline: result.timeline || "4-6 weeks for initial improvements"
    };
  } catch (error) {
    console.error('Recommendations generation error:', error);
    return {
      recommendations: [
        "Focus on consistent practice and form improvement",
        "Work on sport-specific drills and techniques",
        "Incorporate strength and conditioning exercises"
      ],
      focus: currentPerformance.keyArea || "Overall technique",
      timeline: "4-6 weeks for initial improvements"
    };
  }
}
