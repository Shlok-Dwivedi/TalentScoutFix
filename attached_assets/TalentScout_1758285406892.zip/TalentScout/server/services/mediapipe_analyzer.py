#!/usr/bin/env python3
"""
MediaPipe Athletic Performance Analyzer
Analyzes athletic performance using pose estimation and biomechanical analysis
"""

import cv2
import mediapipe as mp
import numpy as np
import json
import sys
import math
from typing import List, Dict, Optional, Tuple

class AthleticPerformanceAnalyzer:
    def __init__(self):
        # Initialize MediaPipe Pose
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=2,  # Higher accuracy
            enable_segmentation=False,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_drawing = mp.solutions.drawing_utils
        
        # Athletic performance metrics
        self.frame_data = []
        self.analysis_results = {
            'technique': 0,
            'power': 0,
            'balance': 0,
            'overallScore': 0,
            'feedback': '',
            'keyArea': '',
            'priority': 'Medium',
            'confidence': 0,
            'pose_data': {
                'joint_angles': {},
                'stability_metrics': {},
                'movement_analysis': {},
                'posture_score': 0
            }
        }

    def calculate_angle(self, a: Tuple[float, float], b: Tuple[float, float], c: Tuple[float, float]) -> float:
        """Calculate angle between three points"""
        a = np.array(a)
        b = np.array(b)
        c = np.array(c)
        
        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
        angle = np.abs(radians * 180.0 / np.pi)
        
        if angle > 180.0:
            angle = 360 - angle
            
        return angle

    def calculate_distance(self, point1: Tuple[float, float], point2: Tuple[float, float]) -> float:
        """Calculate Euclidean distance between two points"""
        return np.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

    def analyze_balance(self, landmarks) -> Dict:
        """Analyze balance and stability from pose landmarks"""
        if not landmarks:
            return {'balance_score': 50, 'stability': 'moderate', 'center_of_mass': [0.5, 0.5]}
        
        # Get key points for balance analysis
        left_ankle = [landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                      landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
        right_ankle = [landmarks[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value].x,
                       landmarks[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value].y]
        left_hip = [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y]
        right_hip = [landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                     landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].y]
        
        # Calculate center of mass approximation
        center_of_mass = [(left_hip[0] + right_hip[0]) / 2, (left_hip[1] + right_hip[1]) / 2]
        
        # Calculate base of support (distance between feet)
        base_of_support = self.calculate_distance(left_ankle, right_ankle)
        
        # Calculate balance score based on center of mass position relative to base of support
        foot_center = [(left_ankle[0] + right_ankle[0]) / 2, (left_ankle[1] + right_ankle[1]) / 2]
        com_displacement = self.calculate_distance(center_of_mass, foot_center)
        
        # Balance score (0-100, higher is better)
        balance_score = max(0, 100 - (com_displacement * 1000))  # Scale factor for scoring
        
        stability = 'excellent' if balance_score > 80 else 'good' if balance_score > 60 else 'needs_improvement'
        
        return {
            'balance_score': min(100, max(0, balance_score)),
            'stability': stability,
            'center_of_mass': center_of_mass,
            'base_of_support': base_of_support,
            'com_displacement': com_displacement
        }

    def analyze_posture(self, landmarks) -> Dict:
        """Analyze posture and alignment"""
        if not landmarks:
            return {'posture_score': 50, 'alignment': 'moderate', 'issues': []}
        
        # Key points for posture analysis
        left_shoulder = [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                         landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        right_shoulder = [landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                          landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
        left_hip = [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
                    landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y]
        right_hip = [landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                     landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].y]
        nose = [landmarks[self.mp_pose.PoseLandmark.NOSE.value].x,
                landmarks[self.mp_pose.PoseLandmark.NOSE.value].y]
        
        issues = []
        posture_score = 100
        
        # Check shoulder alignment
        shoulder_diff = abs(left_shoulder[1] - right_shoulder[1])
        if shoulder_diff > 0.05:  # Threshold for shoulder misalignment
            issues.append("Shoulder misalignment detected")
            posture_score -= 15
        
        # Check hip alignment
        hip_diff = abs(left_hip[1] - right_hip[1])
        if hip_diff > 0.05:  # Threshold for hip misalignment
            issues.append("Hip misalignment detected")
            posture_score -= 15
        
        # Check head position relative to shoulders
        shoulder_center = [(left_shoulder[0] + right_shoulder[0]) / 2, 
                          (left_shoulder[1] + right_shoulder[1]) / 2]
        head_forward = nose[0] - shoulder_center[0]
        if abs(head_forward) > 0.1:  # Threshold for head forward posture
            issues.append("Head posture needs attention")
            posture_score -= 10
        
        alignment = 'excellent' if posture_score > 85 else 'good' if posture_score > 70 else 'needs_improvement'
        
        return {
            'posture_score': max(0, posture_score),
            'alignment': alignment,
            'issues': issues,
            'shoulder_alignment': shoulder_diff,
            'hip_alignment': hip_diff,
            'head_position': head_forward
        }

    def calculate_joint_angles(self, landmarks) -> Dict:
        """Calculate key joint angles for athletic performance"""
        if not landmarks:
            return {}
        
        angles = {}
        
        try:
            # Knee angles
            left_knee_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
            )
            right_knee_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_KNEE.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_KNEE.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_ANKLE.value].y]
            )
            
            # Elbow angles
            left_elbow_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y]
            )
            right_elbow_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_ELBOW.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_ELBOW.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_WRIST.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_WRIST.value].y]
            )
            
            # Hip angles
            left_hip_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_HIP.value].y],
                [landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].x, landmarks[self.mp_pose.PoseLandmark.LEFT_KNEE.value].y]
            )
            right_hip_angle = self.calculate_angle(
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_HIP.value].y],
                [landmarks[self.mp_pose.PoseLandmark.RIGHT_KNEE.value].x, landmarks[self.mp_pose.PoseLandmark.RIGHT_KNEE.value].y]
            )
            
            angles = {
                'left_knee': left_knee_angle,
                'right_knee': right_knee_angle,
                'left_elbow': left_elbow_angle,
                'right_elbow': right_elbow_angle,
                'left_hip': left_hip_angle,
                'right_hip': right_hip_angle
            }
            
        except Exception as e:
            print(f"Error calculating joint angles: {e}", file=sys.stderr)
            
        return angles

    def analyze_movement_quality(self, sport: str = 'general') -> Dict:
        """Analyze overall movement quality and provide sport-specific feedback"""
        if not self.frame_data:
            return {
                'technique_score': 50,
                'power_score': 50,
                'feedback': 'Insufficient data for analysis',
                'recommendations': []
            }
        
        # Calculate averages from all frames
        avg_balance = np.mean([frame['balance']['balance_score'] for frame in self.frame_data if 'balance' in frame])
        avg_posture = np.mean([frame['posture']['posture_score'] for frame in self.frame_data if 'posture' in frame])
        
        # Calculate movement consistency (less variation = better technique)
        joint_angle_variations = []
        if len(self.frame_data) > 1:
            for angle_key in ['left_knee', 'right_knee', 'left_elbow', 'right_elbow']:
                angles = [frame['joint_angles'].get(angle_key, 0) for frame in self.frame_data if 'joint_angles' in frame and angle_key in frame['joint_angles']]
                if angles:
                    variation = np.std(angles)
                    joint_angle_variations.append(variation)
        
        movement_consistency = 100 - min(100, np.mean(joint_angle_variations) if joint_angle_variations else 50)
        
        # Calculate technique score
        technique_score = (avg_balance * 0.3 + avg_posture * 0.4 + movement_consistency * 0.3)
        
        # Calculate power score based on joint angle ranges and movement amplitude
        power_indicators = []
        for frame in self.frame_data:
            if 'joint_angles' in frame:
                angles = frame['joint_angles']
                # Power is often indicated by full range of motion
                knee_rom = abs(angles.get('left_knee', 90) - angles.get('right_knee', 90))
                hip_extension = max(angles.get('left_hip', 90), angles.get('right_hip', 90))
                power_indicators.append(knee_rom + hip_extension)
        
        power_score = min(100, np.mean(power_indicators) if power_indicators else 75)
        
        # Generate feedback
        feedback = self.generate_feedback(technique_score, power_score, avg_balance, avg_posture, sport)
        recommendations = self.generate_recommendations(technique_score, power_score, avg_balance, avg_posture)
        
        return {
            'technique_score': round(technique_score),
            'power_score': round(power_score),
            'balance_score': round(avg_balance),
            'posture_score': round(avg_posture),
            'movement_consistency': round(movement_consistency),
            'feedback': feedback,
            'recommendations': recommendations
        }

    def generate_feedback(self, technique: float, power: float, balance: float, posture: float, sport: str) -> str:
        """Generate human-readable feedback based on analysis"""
        feedback_parts = []
        
        if technique > 85:
            feedback_parts.append("Excellent technique demonstrated with consistent form")
        elif technique > 70:
            feedback_parts.append("Good technique with room for minor improvements")
        else:
            feedback_parts.append("Technique needs significant improvement for optimal performance")
        
        if balance > 85:
            feedback_parts.append("Outstanding balance and stability throughout movement")
        elif balance > 70:
            feedback_parts.append("Good balance with occasional minor instabilities")
        else:
            feedback_parts.append("Balance issues detected - focus on core stability")
        
        if posture > 85:
            feedback_parts.append("Excellent posture and body alignment")
        elif posture > 70:
            feedback_parts.append("Generally good posture with minor alignment issues")
        else:
            feedback_parts.append("Posture correction needed for injury prevention and performance")
        
        return ". ".join(feedback_parts) + "."

    def generate_recommendations(self, technique: float, power: float, balance: float, posture: float) -> List[str]:
        """Generate specific recommendations for improvement"""
        recommendations = []
        
        if technique < 80:
            recommendations.append("Practice form drills with slower, controlled movements")
            recommendations.append("Record yourself from multiple angles to analyze technique")
        
        if balance < 80:
            recommendations.append("Incorporate balance training with single-leg exercises")
            recommendations.append("Strengthen core muscles for better stability")
        
        if posture < 80:
            recommendations.append("Focus on maintaining neutral spine alignment")
            recommendations.append("Strengthen posterior chain muscles (glutes, hamstrings, back)")
        
        if power < 80:
            recommendations.append("Include explosive power training in your routine")
            recommendations.append("Work on full range of motion in key joints")
        
        return recommendations

    def process_video(self, video_path: str, sport: str = 'general') -> Dict:
        """Process video and analyze athletic performance"""
        cap = cv2.VideoCapture(video_path)
        frame_count = 0
        successful_detections = 0
        
        if not cap.isOpened():
            return {
                'error': f'Could not open video file: {video_path}',
                'technique': 50,
                'power': 50,
                'balance': 50,
                'overallScore': 50,
                'feedback': 'Unable to process video file',
                'keyArea': 'Technical setup',
                'priority': 'High',
                'confidence': 0
            }
        
        # Process every 5th frame for efficiency
        frame_skip = 5
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_count += 1
            if frame_count % frame_skip != 0:
                continue
            
            # Convert BGR to RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Process frame with MediaPipe
            results = self.pose.process(rgb_frame)
            
            if results.pose_landmarks:
                successful_detections += 1
                landmarks = results.pose_landmarks.landmark
                
                # Analyze this frame
                frame_analysis = {
                    'timestamp': cap.get(cv2.CAP_PROP_POS_MSEC),
                    'joint_angles': self.calculate_joint_angles(landmarks),
                    'balance': self.analyze_balance(landmarks),
                    'posture': self.analyze_posture(landmarks)
                }
                
                self.frame_data.append(frame_analysis)
        
        cap.release()
        
        if successful_detections == 0:
            return {
                'error': 'No pose landmarks detected in video',
                'technique': 50,
                'power': 50,
                'balance': 50,
                'overallScore': 50,
                'feedback': 'Unable to detect human pose in video. Ensure good lighting and clear view of the athlete.',
                'keyArea': 'Video quality',
                'priority': 'High',
                'confidence': 0
            }
        
        # Analyze overall movement quality
        movement_analysis = self.analyze_movement_quality(sport)
        
        # Calculate overall score
        overall_score = (
            movement_analysis['technique_score'] * 0.4 +
            movement_analysis['power_score'] * 0.3 +
            movement_analysis['balance_score'] * 0.3
        )
        
        # Determine key area for improvement
        scores = {
            'technique': movement_analysis['technique_score'],
            'power': movement_analysis['power_score'],
            'balance': movement_analysis['balance_score']
        }
        key_area = min(scores, key=scores.get)
        
        # Determine priority
        min_score = min(scores.values())
        if min_score < 60:
            priority = 'High'
        elif min_score < 80:
            priority = 'Medium'
        else:
            priority = 'Low'
        
        # Calculate confidence based on detection success rate
        confidence = min(100, (successful_detections / max(1, frame_count // frame_skip)) * 100)
        
        return {
            'technique': round(movement_analysis['technique_score']),
            'power': round(movement_analysis['power_score']),
            'balance': round(movement_analysis['balance_score']),
            'overallScore': round(overall_score),
            'feedback': movement_analysis['feedback'],
            'keyArea': key_area.title(),
            'priority': priority,
            'confidence': round(confidence),
            'pose_data': {
                'total_frames_processed': frame_count // frame_skip,
                'successful_detections': successful_detections,
                'detection_rate': round(confidence, 2),
                'recommendations': movement_analysis['recommendations'],
                'movement_consistency': movement_analysis['movement_consistency']
            }
        }

def main():
    if len(sys.argv) != 3:
        print(json.dumps({
            'error': 'Usage: python mediapipe_analyzer.py <video_path> <sport>',
            'technique': 0,
            'power': 0,
            'balance': 0,
            'overallScore': 0,
            'feedback': 'Invalid usage',
            'keyArea': 'Setup',
            'priority': 'High',
            'confidence': 0
        }))
        sys.exit(1)
    
    video_path = sys.argv[1]
    sport = sys.argv[2].lower()
    
    try:
        analyzer = AthleticPerformanceAnalyzer()
        results = analyzer.process_video(video_path, sport)
        print(json.dumps(results))
    except Exception as e:
        print(f"Error during analysis: {str(e)}", file=sys.stderr)
        print(json.dumps({
            'error': f'Analysis failed: {str(e)}',
            'technique': 50,
            'power': 50,
            'balance': 50,
            'overallScore': 50,
            'feedback': f'Error during analysis: {str(e)}',
            'keyArea': 'Technical issue',
            'priority': 'High',
            'confidence': 0
        }))
        sys.exit(1)

if __name__ == '__main__':
    main()