import {
  type User,
  type InsertUser,
  type VideoAnalysis,
  type InsertVideoAnalysis,
  type PerformanceMetrics,
  type InsertPerformanceMetrics,
  type Coach,
  type InsertCoach,
  type CoachingSession,
  type InsertCoachingSession,
  type Challenge,
  type InsertChallenge,
  type ChallengeProgress,
  type InsertChallengeProgress,
  type SponsorshipProfile,
  type InsertSponsorshipProfile,
  type Badge,
  type InsertBadge,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Video Analysis
  getVideoAnalysis(id: string): Promise<VideoAnalysis | undefined>;
  getVideoAnalysesByUser(userId: string): Promise<VideoAnalysis[]>;
  createVideoAnalysis(analysis: InsertVideoAnalysis): Promise<VideoAnalysis>;
  
  // Performance Metrics
  getPerformanceMetrics(userId: string): Promise<PerformanceMetrics | undefined>;
  updatePerformanceMetrics(userId: string, metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics>;
  
  // Coaches
  getCoach(id: string): Promise<Coach | undefined>;
  getAllCoaches(): Promise<Coach[]>;
  createCoach(coach: InsertCoach): Promise<Coach>;
  
  // Coaching Sessions
  getCoachingSession(id: string): Promise<CoachingSession | undefined>;
  getSessionsByUser(userId: string): Promise<CoachingSession[]>;
  getSessionsByCoach(coachId: string): Promise<CoachingSession[]>;
  createCoachingSession(session: InsertCoachingSession): Promise<CoachingSession>;
  updateCoachingSession(id: string, updates: Partial<CoachingSession>): Promise<CoachingSession | undefined>;
  
  // Challenges
  getChallenge(id: string): Promise<Challenge | undefined>;
  getActiveChallenges(): Promise<Challenge[]>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  
  // Challenge Progress
  getChallengeProgress(userId: string, challengeId: string): Promise<ChallengeProgress | undefined>;
  getUserChallengeProgress(userId: string): Promise<ChallengeProgress[]>;
  updateChallengeProgress(userId: string, challengeId: string, progress: Partial<ChallengeProgress>): Promise<ChallengeProgress>;
  
  // Sponsorship
  getSponsorshipProfile(userId: string): Promise<SponsorshipProfile | undefined>;
  getAllSponsorshipProfiles(): Promise<SponsorshipProfile[]>;
  createSponsorshipProfile(profile: InsertSponsorshipProfile): Promise<SponsorshipProfile>;
  updateSponsorshipProfile(userId: string, updates: Partial<SponsorshipProfile>): Promise<SponsorshipProfile | undefined>;
  
  // Badges
  getUserBadges(userId: string): Promise<Badge[]>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  
  // Leaderboard
  getLeaderboard(filterType?: 'global' | 'local' | 'age', limit?: number): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private videoAnalyses: Map<string, VideoAnalysis>;
  private performanceMetrics: Map<string, PerformanceMetrics>;
  private coaches: Map<string, Coach>;
  private coachingSessions: Map<string, CoachingSession>;
  private challenges: Map<string, Challenge>;
  private challengeProgress: Map<string, ChallengeProgress>;
  private sponsorshipProfiles: Map<string, SponsorshipProfile>;
  private badges: Map<string, Badge>;

  constructor() {
    this.users = new Map();
    this.videoAnalyses = new Map();
    this.performanceMetrics = new Map();
    this.coaches = new Map();
    this.coachingSessions = new Map();
    this.challenges = new Map();
    this.challengeProgress = new Map();
    this.sponsorshipProfiles = new Map();
    this.badges = new Map();
    
    this.initializeData();
  }

  private initializeData() {
    // Create initial user (Alex Rodriguez from the design)
    const alexId = randomUUID();
    const alex: User = {
      id: alexId,
      username: "alex_rodriguez",
      email: "alex@example.com",
      firstName: "Alex",
      lastName: "Rodriguez",
      sport: "Track & Field",
      skillLevel: "Rising",
      age: 22,
      location: "California, USA",
      bio: "Sprint specialist focusing on 100m and 200m events",
      avatar: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      talentScore: 85,
      isActive: true,
    };
    this.users.set(alexId, alex);

    // Create performance metrics for Alex
    const alexMetrics: PerformanceMetrics = {
      id: randomUUID(),
      userId: alexId,
      speed: 94,
      technique: 78,
      endurance: 82,
      power: 89,
      balance: 76,
      agility: 91,
      updatedAt: new Date(),
    };
    this.performanceMetrics.set(alexId, alexMetrics);

    // Create sample coaches
    const coach1Id = randomUUID();
    const coach1: Coach = {
      id: coach1Id,
      firstName: "Michael",
      lastName: "Thompson",
      email: "mthompson@coach.com",
      specialization: "Sprint Technique & Speed Development",
      experience: 12,
      rating: 4.9,
      ratePerHour: 75,
      athletesCoached: 127,
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
      bio: "Former Olympic sprinter with 12 years coaching experience",
      isAvailable: true,
    };
    this.coaches.set(coach1Id, coach1);

    // Create active challenge
    const challengeId = randomUUID();
    const challenge: Challenge = {
      id: challengeId,
      title: "Elite Sprint Challenge",
      description: "Complete 5 speed drills with 85%+ accuracy to earn the Speedster Elite badge",
      type: "weekly",
      requirements: [
        { type: "speed_drills", count: 5, accuracy: 85 },
      ],
      badge: "Speedster Elite",
      prizePool: 500,
      participants: 2847,
      startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      isActive: true,
    };
    this.challenges.set(challengeId, challenge);

    // Create challenge progress for Alex
    const progressId = randomUUID();
    const progress: ChallengeProgress = {
      id: progressId,
      userId: alexId,
      challengeId: challengeId,
      progress: 72,
      completed: false,
      completedAt: null,
      updatedAt: new Date(),
    };
    this.challengeProgress.set(`${alexId}-${challengeId}`, progress);
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      bio: insertUser.bio || null,
      avatar: insertUser.avatar || null,
      talentScore: 0,
      isActive: true,
    };
    this.users.set(id, user);
    
    // Initialize performance metrics
    const metrics: PerformanceMetrics = {
      id: randomUUID(),
      userId: id,
      speed: 0,
      technique: 0,
      endurance: 0,
      power: 0,
      balance: 0,
      agility: 0,
      updatedAt: new Date(),
    };
    this.performanceMetrics.set(id, metrics);
    
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Video Analysis
  async getVideoAnalysis(id: string): Promise<VideoAnalysis | undefined> {
    return this.videoAnalyses.get(id);
  }

  async getVideoAnalysesByUser(userId: string): Promise<VideoAnalysis[]> {
    return Array.from(this.videoAnalyses.values()).filter(analysis => analysis.userId === userId);
  }

  async createVideoAnalysis(insertAnalysis: InsertVideoAnalysis): Promise<VideoAnalysis> {
    const id = randomUUID();
    const analysis: VideoAnalysis = {
      ...insertAnalysis,
      id,
      description: insertAnalysis.description || null,
      thumbnailUrl: insertAnalysis.thumbnailUrl || null,
      keyArea: insertAnalysis.keyArea || null,
      priority: insertAnalysis.priority || null,
      createdAt: new Date(),
    };
    this.videoAnalyses.set(id, analysis);
    return analysis;
  }

  // Performance Metrics
  async getPerformanceMetrics(userId: string): Promise<PerformanceMetrics | undefined> {
    return this.performanceMetrics.get(userId);
  }

  async updatePerformanceMetrics(userId: string, metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics> {
    const existing = this.performanceMetrics.get(userId);
    const updated: PerformanceMetrics = {
      id: existing?.id || randomUUID(),
      userId,
      speed: metrics.speed || null,
      technique: metrics.technique || null,
      endurance: metrics.endurance || null,
      power: metrics.power || null,
      balance: metrics.balance || null,
      agility: metrics.agility || null,
      updatedAt: new Date(),
    };
    this.performanceMetrics.set(userId, updated);
    return updated;
  }

  // Coaches
  async getCoach(id: string): Promise<Coach | undefined> {
    return this.coaches.get(id);
  }

  async getAllCoaches(): Promise<Coach[]> {
    return Array.from(this.coaches.values());
  }

  async createCoach(insertCoach: InsertCoach): Promise<Coach> {
    const id = randomUUID();
    const coach: Coach = {
      ...insertCoach,
      id,
      bio: insertCoach.bio || null,
      avatar: insertCoach.avatar || null,
      rating: 0,
      athletesCoached: 0,
      isAvailable: true,
    };
    this.coaches.set(id, coach);
    return coach;
  }

  // Coaching Sessions
  async getCoachingSession(id: string): Promise<CoachingSession | undefined> {
    return this.coachingSessions.get(id);
  }

  async getSessionsByUser(userId: string): Promise<CoachingSession[]> {
    return Array.from(this.coachingSessions.values()).filter(session => session.userId === userId);
  }

  async getSessionsByCoach(coachId: string): Promise<CoachingSession[]> {
    return Array.from(this.coachingSessions.values()).filter(session => session.coachId === coachId);
  }

  async createCoachingSession(insertSession: InsertCoachingSession): Promise<CoachingSession> {
    const id = randomUUID();
    const session: CoachingSession = {
      ...insertSession,
      id,
      notes: insertSession.notes || null,
      rating: insertSession.rating || null,
      createdAt: new Date(),
    };
    this.coachingSessions.set(id, session);
    return session;
  }

  async updateCoachingSession(id: string, updates: Partial<CoachingSession>): Promise<CoachingSession | undefined> {
    const session = this.coachingSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.coachingSessions.set(id, updatedSession);
    return updatedSession;
  }

  // Challenges
  async getChallenge(id: string): Promise<Challenge | undefined> {
    return this.challenges.get(id);
  }

  async getActiveChallenges(): Promise<Challenge[]> {
    const now = new Date();
    return Array.from(this.challenges.values()).filter(
      challenge => challenge.isActive && challenge.endDate > now
    );
  }

  async createChallenge(insertChallenge: InsertChallenge): Promise<Challenge> {
    const id = randomUUID();
    const challenge: Challenge = {
      ...insertChallenge,
      id,
      badge: insertChallenge.badge || null,
      prizePool: insertChallenge.prizePool || null,
      participants: 0,
      isActive: true,
    };
    this.challenges.set(id, challenge);
    return challenge;
  }

  // Challenge Progress
  async getChallengeProgress(userId: string, challengeId: string): Promise<ChallengeProgress | undefined> {
    return this.challengeProgress.get(`${userId}-${challengeId}`);
  }

  async getUserChallengeProgress(userId: string): Promise<ChallengeProgress[]> {
    return Array.from(this.challengeProgress.values()).filter(progress => progress.userId === userId);
  }

  async updateChallengeProgress(userId: string, challengeId: string, updates: Partial<ChallengeProgress>): Promise<ChallengeProgress> {
    const key = `${userId}-${challengeId}`;
    const existing = this.challengeProgress.get(key);
    
    const progress: ChallengeProgress = {
      id: existing?.id || randomUUID(),
      userId,
      challengeId,
      progress: existing?.progress || 0,
      completed: existing?.completed || false,
      completedAt: existing?.completedAt || null,
      updatedAt: new Date(),
      ...updates,
    };
    
    this.challengeProgress.set(key, progress);
    return progress;
  }

  // Sponsorship
  async getSponsorshipProfile(userId: string): Promise<SponsorshipProfile | undefined> {
    return Array.from(this.sponsorshipProfiles.values()).find(profile => profile.userId === userId);
  }

  async getAllSponsorshipProfiles(): Promise<SponsorshipProfile[]> {
    return Array.from(this.sponsorshipProfiles.values()).filter(profile => profile.isActive);
  }

  async createSponsorshipProfile(insertProfile: InsertSponsorshipProfile): Promise<SponsorshipProfile> {
    const id = randomUUID();
    const profile: SponsorshipProfile = {
      ...insertProfile,
      id,
      achievements: insertProfile.achievements || null,
      trainingHours: insertProfile.trainingHours || null,
      recentAchievement: insertProfile.recentAchievement || null,
      currentFunding: 0,
      sponsorCount: 0,
      isActive: true,
    };
    this.sponsorshipProfiles.set(id, profile);
    return profile;
  }

  async updateSponsorshipProfile(userId: string, updates: Partial<SponsorshipProfile>): Promise<SponsorshipProfile | undefined> {
    const profile = Array.from(this.sponsorshipProfiles.values()).find(p => p.userId === userId);
    if (!profile) return undefined;
    
    const updatedProfile = { ...profile, ...updates };
    this.sponsorshipProfiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  // Badges
  async getUserBadges(userId: string): Promise<Badge[]> {
    return Array.from(this.badges.values()).filter(badge => badge.userId === userId);
  }

  async createBadge(insertBadge: InsertBadge): Promise<Badge> {
    const id = randomUUID();
    const badge: Badge = {
      ...insertBadge,
      id,
      description: insertBadge.description || null,
      icon: insertBadge.icon || null,
      earnedAt: new Date(),
    };
    this.badges.set(id, badge);
    return badge;
  }

  // Leaderboard
  async getLeaderboard(filterType: 'global' | 'local' | 'age' = 'global', limit: number = 10): Promise<User[]> {
    const users = Array.from(this.users.values())
      .filter(user => user.isActive)
      .sort((a, b) => (b.talentScore || 0) - (a.talentScore || 0));
    
    // For now, just return top users regardless of filter
    // In a real implementation, you'd filter by location for 'local' and age range for 'age'
    return users.slice(0, limit);
  }
}

export const storage = new MemStorage();
