import express, { type Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { analysisService } from "./services/analysisService";
import { videoProcessor } from "./services/videoProcessor";
import {
  insertUserSchema,
  insertVideoAnalysisSchema,
  insertPerformanceMetricsSchema,
  insertCoachingSessionSchema,
  insertChallengeProgressSchema,
  insertSponsorshipProfileSchema,
} from "@shared/schema";
import { z } from "zod";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

// Configure multer for video uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
  fileFilter: (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = ['video/mp4', 'video/mov', 'video/quicktime', 'video/avi'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only MP4, MOV, and AVI are allowed.'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Users endpoints
  app.get("/api/users/current", async (req, res) => {
    // In a real app, you'd get the user from session/JWT
    // For now, return the default user (Alex Rodriguez)
    const users = await storage.getAllUsers();
    const currentUser = users[0];
    if (!currentUser) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(currentUser);
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Failed to update user", error });
    }
  });

  // Performance metrics endpoints
  app.get("/api/users/:userId/metrics", async (req, res) => {
    try {
      const { userId } = req.params;
      const metrics = await storage.getPerformanceMetrics(userId);
      if (!metrics) {
        return res.status(404).json({ message: "Metrics not found" });
      }
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to get metrics", error });
    }
  });

  app.put("/api/users/:userId/metrics", async (req, res) => {
    try {
      const { userId } = req.params;
      const metricsData = insertPerformanceMetricsSchema.parse(req.body);
      const metrics = await storage.updatePerformanceMetrics(userId, metricsData);
      res.json(metrics);
    } catch (error) {
      res.status(400).json({ message: "Invalid metrics data", error });
    }
  });

  // Video analysis endpoints
  app.post("/api/videos/analyze", upload.single('video'), async (req: MulterRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file provided" });
      }

      const { userId, title, description } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      // Get user info for sport context
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Process video
      const processedVideo = await videoProcessor.processVideo(req.file.buffer, req.file.originalname);
      
      // Analyze with MediaPipe (primary) or OpenAI (fallback)  
      const analysisResult = await analysisService.analyzeVideo(
        processedVideo.videoPath,
        user.sport,
        processedVideo.frames
      );
      
      // Save analysis to storage
      const analysisData = {
        userId,
        videoUrl: processedVideo.videoPath,
        thumbnailUrl: processedVideo.thumbnailPath,
        title: title || "Video Analysis",
        description: description || "",
        technique: analysisResult.technique,
        power: analysisResult.power,
        balance: analysisResult.balance,
        overallScore: analysisResult.overallScore,
        aiFeedback: analysisResult.feedback,
        keyArea: analysisResult.keyArea,
        priority: analysisResult.priority,
        confidence: analysisResult.confidence,
      };

      const analysis = await storage.createVideoAnalysis(analysisData);

      // Enhance response with pose data and analysis method
      const enhancedResponse = {
        ...analysis,
        pose_data: analysisResult.pose_data,
        analysis_method: analysisResult.analysis_method,
        biomechanical_insights: analysisResult.pose_data ? {
          movement_consistency: analysisResult.pose_data.movement_consistency,
          detection_quality: `${analysisResult.pose_data.detection_rate}% detection rate`,
          frames_analyzed: analysisResult.pose_data.total_frames_processed,
          recommendations: analysisResult.pose_data.recommendations
        } : null
      };

      // Update user's talent score based on new analysis
      const currentScore = user.talentScore || 0;
      const newScore = Math.round((currentScore + analysisResult.overallScore) / 2);
      await storage.updateUser(userId, { talentScore: newScore });

      res.json(enhancedResponse);
    } catch (error) {
      console.error("Video analysis error:", error);
      const message = error instanceof Error ? error.message : 'Unknown error occurred';
      res.status(500).json({ message: "Failed to analyze video", error: message });
    }
  });

  app.get("/api/users/:userId/videos", async (req, res) => {
    try {
      const { userId } = req.params;
      const analyses = await storage.getVideoAnalysesByUser(userId);
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Failed to get video analyses", error });
    }
  });

  app.get("/api/videos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const analysis = await storage.getVideoAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: "Video analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to get video analysis", error });
    }
  });

  // Leaderboard endpoints
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const { filter = 'global', limit = 10 } = req.query;
      const leaderboard = await storage.getLeaderboard(
        filter as 'global' | 'local' | 'age',
        parseInt(limit as string)
      );
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to get leaderboard", error });
    }
  });

  // Coaches endpoints
  app.get("/api/coaches", async (req, res) => {
    try {
      const coaches = await storage.getAllCoaches();
      res.json(coaches);
    } catch (error) {
      res.status(500).json({ message: "Failed to get coaches", error });
    }
  });

  app.get("/api/coaches/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: "Coach not found" });
      }
      res.json(coach);
    } catch (error) {
      res.status(500).json({ message: "Failed to get coach", error });
    }
  });

  // Coaching sessions endpoints
  app.get("/api/users/:userId/sessions", async (req, res) => {
    try {
      const { userId } = req.params;
      const sessions = await storage.getSessionsByUser(userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get sessions", error });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertCoachingSessionSchema.parse(req.body);
      const session = await storage.createCoachingSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data", error });
    }
  });

  app.put("/api/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const session = await storage.updateCoachingSession(id, updates);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(400).json({ message: "Failed to update session", error });
    }
  });

  // Challenges endpoints
  app.get("/api/challenges", async (req, res) => {
    try {
      const challenges = await storage.getActiveChallenges();
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: "Failed to get challenges", error });
    }
  });

  app.get("/api/users/:userId/challenges", async (req, res) => {
    try {
      const { userId } = req.params;
      const progress = await storage.getUserChallengeProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to get challenge progress", error });
    }
  });

  app.put("/api/users/:userId/challenges/:challengeId", async (req, res) => {
    try {
      const { userId, challengeId } = req.params;
      const updates = req.body;
      const progress = await storage.updateChallengeProgress(userId, challengeId, updates);
      res.json(progress);
    } catch (error) {
      res.status(400).json({ message: "Failed to update challenge progress", error });
    }
  });

  // Sponsorship endpoints
  app.get("/api/sponsorship/profiles", async (req, res) => {
    try {
      const profiles = await storage.getAllSponsorshipProfiles();
      // Get user data for each profile
      const profilesWithUsers = await Promise.all(
        profiles.map(async (profile) => {
          const user = await storage.getUser(profile.userId);
          return { ...profile, user };
        })
      );
      res.json(profilesWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get sponsorship profiles", error });
    }
  });

  app.get("/api/users/:userId/sponsorship", async (req, res) => {
    try {
      const { userId } = req.params;
      const profile = await storage.getSponsorshipProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Sponsorship profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to get sponsorship profile", error });
    }
  });

  app.post("/api/users/:userId/sponsorship", async (req, res) => {
    try {
      const { userId } = req.params;
      const profileData = { ...req.body, userId };
      const profile = await storage.createSponsorshipProfile(profileData);
      res.status(201).json(profile);
    } catch (error) {
      res.status(400).json({ message: "Invalid sponsorship profile data", error });
    }
  });

  // Badges endpoints
  app.get("/api/users/:userId/badges", async (req, res) => {
    try {
      const { userId } = req.params;
      const badges = await storage.getUserBadges(userId);
      res.json(badges);
    } catch (error) {
      res.status(500).json({ message: "Failed to get badges", error });
    }
  });

  // Training recommendations endpoint
  app.get("/api/users/:userId/recommendations", async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await storage.getUser(userId);
      const metrics = await storage.getPerformanceMetrics(userId);
      const recentAnalyses = await storage.getVideoAnalysesByUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Create a mock analysis result based on recent data for recommendations
      const lastAnalysis = recentAnalyses[0];
      const mockAnalysisResult = {
        technique: lastAnalysis?.technique || metrics?.technique || 75,
        power: lastAnalysis?.power || metrics?.power || 75,
        balance: lastAnalysis?.balance || metrics?.balance || 75,
        overallScore: lastAnalysis?.overallScore || 75,
        feedback: lastAnalysis?.aiFeedback || "Continue practicing consistently",
        keyArea: lastAnalysis?.keyArea || "Form and technique",
        priority: (lastAnalysis?.priority || "Medium") as 'Low' | 'Medium' | 'High',
        confidence: lastAnalysis?.confidence || 80,
        analysis_method: 'fallback' as const
      };
      
      const recommendations = await analysisService.generateRecommendations(
        `Improve ${user.sport} performance`,
        mockAnalysisResult,
        user.sport
      );
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recommendations", error });
    }
  });

  // Dashboard data endpoint
  app.get("/api/dashboard/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      
      const [user, metrics, recentAnalyses, challenges, sessions, badges] = await Promise.all([
        storage.getUser(userId),
        storage.getPerformanceMetrics(userId),
        storage.getVideoAnalysesByUser(userId),
        storage.getUserChallengeProgress(userId),
        storage.getSessionsByUser(userId),
        storage.getUserBadges(userId),
      ]);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const dashboardData = {
        user,
        metrics,
        recentAnalyses: recentAnalyses.slice(0, 3),
        activeChallenges: challenges.filter(c => !c.completed),
        upcomingSessions: sessions.filter(s => s.status === 'scheduled'),
        badges: badges.slice(0, 6),
      };

      res.json(dashboardData);
    } catch (error) {
      res.status(500).json({ message: "Failed to get dashboard data", error });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  const httpServer = createServer(app);
  return httpServer;
}
